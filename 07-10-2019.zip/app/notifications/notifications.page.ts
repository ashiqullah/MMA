import { Component, OnInit } from '@angular/core';
import { notificationProvider } from '../providers/notifications/notification';
import {Events, ModalController, AlertController, MenuController } from '@ionic/angular';
import { Router } from '@angular/router';

import {ArticlePage} from '../article/article.page';
import {CastsPage} from '../casts/casts.page';
import {ResurcesPage} from '../resurces/resurces.page';

import { TranslateService } from '@ngx-translate/core';
import { Service } from '../settings/Laravel';
import { UserProfilePage } from '../user-profile/user-profile.page';


@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.page.html',
  styleUrls: ['./notifications.page.scss'],
})
export class NotificationsPage implements OnInit {
  ServerUrl: string;
  Maleimage: string;
  Femaleimage: string;
  notifcations: any[];
  constructor(
    private notificationservice: notificationProvider,
    public events: Events,
    public router: Router,
    public modalController: ModalController,
    private alertCtrl: AlertController,
    public translateService: TranslateService,
    private menu: MenuController,
    public translate: TranslateService




  ) {

    this.ServerUrl = Service.url;
    this.Maleimage = Service.maleImageUrl;
    this.Femaleimage = Service.femaleImageUrl;
    this.notificationservice.getnotifications().then((response: any) => {

this.notifcations = response;
console.log(response);
    });
   }

  async itemclicked(itemid, entity_type, entity_id, index) {

    this.notificationservice.getNotificationView(itemid).then((reponse: any) => {
      this.events.publish('Notification:viewed', reponse);
    });
    this.notifcations.splice(index, 1);

    if (entity_type === 'casts') {
      let modal = await this.modalController.create({
        component: CastsPage,
        componentProps: { castid: entity_id }
      });
      modal.present();


    } else if (entity_type === 'forum') {
      let modal = await this.modalController.create({
        component: ArticlePage,
        componentProps: { articleid: entity_id }
      });
      modal.present();

    }
    else if (entity_type === 'Resources') {
      let modal = await this.modalController.create({
        component: ResurcesPage,
        componentProps: { sourceid: entity_id }
      });
      modal.present();

    }
    

    
   }
   clearNotifications() {
     this.notificationservice.clearNotification().then((response: any)=>{
       this.notifcations=[];
      this.events.publish('Notification:viewed', 0);

     });
   }


 async  done() {
  const alert =await this.alertCtrl.create({
      header: this.translateService.instant('ALERT'),
      message: this.translateService.instant('CLEARALLNOTIFICATIONS'),
      buttons: [
        {
          text:this.translateService.instant('CANCEL')
        },
        {
          text: this.translateService.instant('YES'),
          handler: data => {
            this.clearNotifications();
          }
        }
      ]
    });
  alert.present();
  }


  ngOnInit() {
   
  }
  async presentModal(profileId: number) {
    const modal = await this.modalController.create({
      component: UserProfilePage,
      componentProps: { value: profileId }
    });
    return await modal.present();
  }
}
