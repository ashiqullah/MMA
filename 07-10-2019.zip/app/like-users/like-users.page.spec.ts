import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LikeUsersPage } from './like-users.page';

describe('LikeUsersPage', () => {
  let component: LikeUsersPage;
  let fixture: ComponentFixture<LikeUsersPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LikeUsersPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LikeUsersPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
