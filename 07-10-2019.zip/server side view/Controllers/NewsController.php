<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\News;
use App\User;
use DB;
use App;
use App\UserContactGroup;

use App\Traits\NotificationTrait;
use App\Notification;
use App\Traits\SystemLogTrait;

class NewsController extends Controller
{
  use SystemLogTrait;
  use NotificationTrait;

  function __construct()
  {
    $this->middleware('auth');
  }

    # Show News
  public function show($news_id)
  {

    if(App::getLocale() == 'en'){
      $news = DB::table('news')->where('news.id', $news_id)
      ->whereNotNull('news.en_title')
      ->join('users', 'users.id', '=', 'news.user_id')
      ->select('users.name as username', 'news.*')
      ->first();
    }

    elseif(App::getLocale() == 'da'){
      $news = DB::table('news')->where('news.id', $news_id)
      ->whereNotNull('news.da_title')
      ->join('users', 'users.id', '=', 'news.user_id')
      ->select('users.name as username', 'news.*')
      ->first();
    }

    else{
      $news = DB::table('news')->where('news.id', $news_id)
      ->whereNotNull('news.ps_title')
      ->join('users', 'users.id', '=', 'news.user_id')
      ->select('users.name as username', 'news.*')
      ->first();
    }

    $about = DB::table('pages')->where('id', 1)->first();

    if(App::getLocale() == 'en'){
      $recent_news = DB::table('news')
      ->whereNotNull('en_title')
      ->limit(5)
      ->orderBy('id', 'desc')
      ->get();
    }
    elseif(App::getLocale() == 'da'){
      $recent_news = DB::table('news')
      ->whereNotNull('da_title')
      ->limit(5)
      ->orderBy('id', 'desc')
      ->get();
    }

    else{
      $recent_news = DB::table('news')
      ->whereNotNull('ps_title')
      ->limit(5)
      ->orderBy('id', 'desc')
      ->get();
    }
    

      //return response()->json($news);
    return view('news.show', compact('news', 'recent_news', 'about'));
  }

    # News Home Page
  public function news()
  {
      // User Coalitions
    $user_coalitions = DB::table('user_coalitions')->where('user_id', Auth::id())
    ->select('coalition_id')
    ->get();
      // Create Array
    foreach($user_coalitions as $obj):
      $uc_array[] = $obj->coalition_id;
    endforeach;

      // Categories
    $categories = array();

    foreach($uc_array as $key => $value)
    {
      $category =  DB::table("news_categories")->where('coalition_id', $value)->where('status', 1)->first();
      if(!empty($category))
      $categories[] = $category;
    }


      // Add General Category ID ( Session Control )
    array_push($uc_array, 0);

    if(App::getLocale() == 'en'){
      $news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.en_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
        })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->paginate(6);
      
      $all_news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.en_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
        })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->limit(50)->get();
    }

    elseif(App::getLocale() == 'da'){
      $news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.da_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
     })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->paginate(6);
      
      $all_news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.da_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
     })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->limit(50)->get();
    }
    else{
      $news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.ps_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
     })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->paginate(6);
      
      $all_news = DB::table('news')->where('news.status', '=',  1)
      ->whereNotNull('news.ps_content')
      ->where(function($query){
       $query->where('news.expire_date', '>=', Date('Y-m-d'));
       $query->orWhere('news.expire_date', null);
     })
      ->orderby('id', 'desc')
      ->join('users', 'users.id', 'news.user_id')
      ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
      ->whereIn('news_categories.coalition_id', $uc_array)
      ->select('news.*', 'users.name as username')
      ->limit(50)->get();
    }

    $contactGroups = DB::table('contact_groups')->orderBy('contact_groups.id', 'asc')->get();

    $coalitions = DB::table('user_coalitions')->orderBy('user_coalitions.id', 'desc')
    ->join('coalitions', 'user_coalitions.coalition_id', '=', 'coalitions.id')
    ->select('coalitions.*')
    ->where('user_coalitions.user_id', Auth::id())
    ->get();


    return view('news.news', compact('news', 'all_news', 'categories', 'contactGroups', 'coalitions'));
  }

  /* Add */
  public function add(Request $request)
  { 
    // Validate data
    $this->validate($request,[
      'image' => 'nullable|image',
      'category' => 'required',
      'type' => 'required',
      'expire_date' => 'nullable|date',
      'image' => 'file|max:1024'
    ]);
    
    $newslang = $request->newslang;
    $en_title=$request->en_title;
    $da_title=$request->da_title;
    $ps_title = $request->ps_title;
    $en_content= $request->en_content;
    $da_content =$request->da_content;
    $ps_content=$request->ps_content;
    $category = $request->category;
    $type = $request->type;
    $user_id = Auth::id();

    // if(!isEmpty($request->status)){
  //  $status =  $request->status;
 /*    }
    else
    {
    $status =0;

    } */
    if ($request->has('status')) {
    $status =  $request->status;
    // 
  }
  else
  {
    $status =0;

  }


    $news = new News;

    // Upload Image
    $image_path="";
    if(!empty($request->file('image'))){
        $file= $request->file('image');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'upload/2018/04/';
        $filename = $filename . '.' . $fileExt;
        $image_path=$file->move($destinationPath, $filename);
    }

    $news->en_title = $en_title;
    $news->da_title = $da_title;
    $news->ps_title = $ps_title;
    $news->en_content = $en_content;
    $news->da_content = $da_content;
    $news->ps_content = $ps_content;
    $news->image = $image_path;
    $news->category_id = $category;
    $news->type = $type;
    $news->user_id = $user_id;
    $news->status = $status;
    $news->expire_date = $request->expire_date;
    $news->notify = true;
    $news->notify_groups = $request->notify_groups;
    $news->notify_coalitions = isset($request->notify_coalitions) ? implode(',', $request->notify_coalitions) : null;
    $news->save();

	$notifyGroups = $request->notify_groups;
		$users = UserContactGroup::where('contact_group_id', 3)->pluck('user_id')->all();
		$emails = User::whereIn('id', $users)->where('status', 1)->pluck('email')->all();
		foreach( $emails as $email){
	        $this->sendNotificationToApplicant($email," ".Auth::user()->name ."&nbsp". Auth::user()->last_name." Added a news or Event to KMPM");
		}
		
		//create system notification
		foreach($users as $user){
	        $this->createNotification($user, Auth::user()->name." Added a news or Event to KMPM", "news", $news->id);
		}

    return redirect('/news')->with('msg', 'Your news item has been submitted for admin approval.');

  }

  public function addajax(Request $request)
  { 
    // Validate data
    $this->validate($request,[
      'image' => 'nullable|image',
      'category' => 'required',
      'type' => 'required',
      'expire_date' => 'nullable|date',
      'image' => 'file|max:1024'
    ]);
    
    $newslang = $request->newslang;
    $en_title=$request->en_title;
    $da_title=$request->da_title;
    $ps_title = $request->ps_title;
    $en_content= $request->en_content;
    $da_content =$request->da_content;
    $ps_content=$request->ps_content;
    $category = $request->category;
    $type = $request->type;
    $user_id = Auth::id();

    // if(!isEmpty($request->status)){
  //  $status =  $request->status;
 /*    }
    else
    {
    $status =0;

    } */
    if ($request->has('status')) {
    $status =  $request->status;
    // 
  }
  else
  {
    $status =0;

  }


    $news = new News;

    // Upload Image
    $image_path="";
    if(!empty($request->file('image'))){
        $file= $request->file('image');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'upload/2018/04/';
        $filename = $filename . '.' . $fileExt;
        $image_path=$file->move($destinationPath, $filename);
    }

    $news->en_title = $en_title;
    $news->da_title = $da_title;
    $news->ps_title = $ps_title;
    $news->en_content = $en_content;
    $news->da_content = $da_content;
    $news->ps_content = $ps_content;
    $news->image = $image_path;
    $news->category_id = $category;
    $news->type = $type;
    $news->user_id = $user_id;
    $news->status = $status;
    $news->expire_date = $request->expire_date;
    $news->notify = true;
    $news->notify_groups = $request->notify_groups;
    $news->notify_coalitions = isset($request->notify_coalitions) ? implode(',', $request->notify_coalitions) : null;
    $news->save();

	$notifyGroups = $request->notify_groups;
		$users = UserContactGroup::where('contact_group_id', 3)->pluck('user_id')->all();
		$emails = User::whereIn('id', $users)->where('status', 1)->pluck('email')->all();
		foreach( $emails as $email){
	        $this->sendNotificationToApplicant($email," ".Auth::user()->name ."&nbsp". Auth::user()->last_name." Added a news or Event to KMPM");
		}
		
		//create system notification
		foreach($users as $user){
	        $this->createNotification($user, Auth::user()->name." Added a news or Event to KMPM", "news", $news->id);
		}

   // return redirect('/news')->with('msg', 'Your news item has been submitted for admin approval.');
    return response()->json(['message' => 'Your news item has been submitted for admin approval.']);


  }

  /* Edit News */
  public function edit($news_id)
  {
    // Get News Item
    $news = DB::table('news')->where('news.id', $news_id)
    ->where('news.user_id', Auth::id())
    ->join('news_categories', 'news_categories.id', '=', 'news.category_id')
    ->select('news.*', 'news_categories.en_title as category')
    ->first();
    $categories = DB::table('news_categories')->get();
    $contactGroups = DB::table('contact_groups')->orderBy('contact_groups.id', 'asc')->get();
    return view('news.edit', compact('news', 'categories', 'contactGroups'));
  }

  /* Update */
  public function update(Request $request)
  {
       // Validate
      $this->validate($request, [
        'category' => 'required',
        'type' => 'required',          
        'expire_date' => 'nullable|date'
      ]);
    
          // Update Image
      $image = $request->file('image');
      if(!empty($image))
      {
            // New Image Path
        $image_path="";
        if(!empty($image)){
            $file= $image;
            $filename         = str_random(12);
            $fileExt          = $file->getClientOriginalExtension();
            $destinationPath  = 'upload/2018/04/';
            $filename = $filename . '.' . $fileExt;
            $image_path=$file->move($destinationPath, $filename);
        }
    
            // Old Image path
        $old_image = DB::table('news')->where('id', $request->id)->select('image')->first()->image;
    
            // Delete Old Image
        if(!empty($old_image) and file_exists($old_image))
        {
          try
          {
            unlink($old_image);
          } catch (Exception $ex) {
            echo $ex;
          }
        }
    
            // Update New Image to the Database
        DB::table('news')->where('id', $request->id)->update([
          'image' => $image_path
        ]);
      }
          // Update news
      DB::table('news')->where('id', $request->id)->update([
        'en_title' => $request->en_title,
        'da_title' => $request->da_title,
        'ps_title' => $request->ps_title,
        'en_content' => $request->en_content,
        'da_content' => $request->da_content,
        'ps_content' => $request->ps_content,
        'notify_groups' => $request->notify_groups,
        'category_id' => $request->category,
        'type' => $request->type,
        'expire_date' => $request->expire_date,
        'status'=>$request->status,
      ]);
    
      $this->createLog($this->getFullName(DB::table('news')->where('id', $request->id)->first()->user_id)." updated their News and Event.");

      // Return with Success Message
    return redirect('/news')->with('msg', 'Changes have been saved and sent for admin approval.');
  }

  /* Delete News */
  public function delete($news_id)
  {
     // Get News
    $news = News::with('notifications')->findOrFail($news_id);

      // Get Image
    $image = $news->image;

      // Delete Image
    if(!empty($image))
    {
      unlink($image);
    }
    
      foreach($news->notifications as $not){
          Notification::find($not->id)->delete();
      }
    News::find($news->id)->delete();

      // Delete News from database
    $news->delete();

      // Return with success message
    return redirect('news')->with('msg', 'News item deleted successfully!');
  }


  public function deleteajax($news_id)
  {
     // Get News
    $news = News::with('notifications')->findOrFail($news_id);

      // Get Image
    $image = $news->image;

      // Delete Image
    if(!empty($image))
    {
      unlink($image);
    }
    
      foreach($news->notifications as $not){
          Notification::find($not->id)->delete();
      }
    News::find($news->id)->delete();

      // Delete News from database
    $news->delete();

      // Return with success message
    return response()->json($news_id);
  }

  function getdropdowndata()
  {

    $contactGroups = DB::table('contact_groups')->orderBy('contact_groups.id', 'asc')->get();

    $coalitions = DB::table('user_coalitions')->orderBy('user_coalitions.id', 'desc')
    ->join('coalitions', 'user_coalitions.coalition_id', '=', 'coalitions.id')
    ->select('coalitions.*')
    ->where('user_coalitions.user_id', Auth::id())
    ->get();

    $user_coalitions = DB::table('user_coalitions')->where('user_id', Auth::id())
    ->select('coalition_id')
    ->get();
      // Create Array
    foreach($user_coalitions as $obj):
      $uc_array[] = $obj->coalition_id;
    endforeach;

      // Categories
    $categories = array();

    foreach($uc_array as $key => $value)
    {
      $category =  DB::table("news_categories")->where('coalition_id', $value)->where('status', 1)->first();
      if(!empty($category))
      $categories[] = $category;
    }




/* 
    if(Auth::user()->user_type==1){
      $coalitions = DB::table('user_coalitions')->orderBy('user_coalitions.id', 'desc')
    ->join('coalitions', 'user_coalitions.coalition_id', '=', 'coalitions.id')
    ->select('coalitions.*')
    ->get();
  }else {
    $coalitions = DB::table('user_coalitions')->orderBy('user_coalitions.id', 'desc')
    ->join('coalitions', 'user_coalitions.coalition_id', '=', 'coalitions.id')
    ->select('coalitions.*')
    ->where('user_coalitions.user_id', Auth::id())
    ->get();
  } */
    

    return response()->json(['Contactgroups' => $contactGroups, 'Coalition' => $categories]);

  }
  
  


}
