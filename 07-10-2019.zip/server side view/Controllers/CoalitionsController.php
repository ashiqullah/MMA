<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Coalitions;
use Illuminate\Support\Facades\Auth;

class CoalitionsController extends Controller
{
    function __construct()
  {
    $this->middleware('auth');
    $this->middleware('checkPermissions');
  }
    # Home
    public function home()
    {
        $coalitions = Coalitions::with('leaders')->orderBy('location', 'asc')
            ->where('status', '=', 1)
            ->Orwhere('status', '=', 2)
            ->get();

        return view('coalitions.home', compact('coalitions'));
    }

    # Display Coalition background
    public function background($slug)
    {
        $coalition = DB::table('coalitions')->where('slug', $slug)
            ->first();
        $other_coalitions = DB::table('coalitions')->get();
        return view('coalitions.background', compact('coalition', 'other_coalitions'));
    }


    function homedetails($id){

        $coalitions = DB::table('coalitions')->orderBy('location', 'asc')
            // ->where('status', '=', 1)
            ->Orwhere('id',$id)
            ->get();

        return view('coalitions.homedetails', compact('coalitions'));

    }

    public function leadership()
    {
        return view('coalitions.leadership');
    }

    public function coalitionDeputies($coalition_id)
    {
        $coalition = Coalitions::with('leaders')->where('id', $coalition_id)->first();
        return response()->json($coalition);
    }

	public function getCoalitionsAjax()
    {
        $coalitions = Coalitions::with('leaders')->orderBy('location', 'asc')
            ->where('status', '=', 1)
            ->Orwhere('status', '=', 2)
            ->get();

        return response()->json($coalitions);
    }

}
