<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
//Route::get('/forum/category/{category_id}', 'ForumController@category');

    Route::middleware('auth:api')->group( function () {
    Route::resource('forum', 'ForumController@category');
    Route::get('/forum/category/{category_id}', 'ForumController@category');
    Route::get('/forum/article/like/{article_id}', 'ForumController@likeArticle');
    Route::get('/forum/article/like/{article_id}', 'ForumController@likeArticle');
    //new 
    Route::get('/forum/allcategories/{category_id}', 'ForumController@allcategories');
    Route::get('/forum/article/likecomment/{id}', 'ForumController@likecomment');
    Route::get('/forum/article/likereply/{id}', 'ForumController@likeReply');
    Route::post('/replytocomment_add', 'ForumController@replytocomment_add');
    Route::post('/forum/save_reply', 'ForumController@save_reply');
    Route::get('/forum/delete_usercomment/{comment_id}', 'ForumController@delete_usercomment');
    Route::get('/delete/your/reply/{id}', 'ForumController@deletereply');
    Route::get('/users/profile/ajax/{article_id}', 'UserController@showProfileByAjax');
    Route::post('/forum/save_article', 'ForumController@save_article');
    Route::get('/forum/getCommentsajax/{article_id}', 'ForumController@getCommentsajax');
    Route::get('/forum/getCommentsajaxMore/{article_id}/{id}', 'ForumController@getCommentsajaxMore');
   Route::post('/forum/update_comment', 'ForumController@update_comment');
  Route::post('/forum/update_reply', 'ForumController@update_reply');
  Route::get('/forum/article/{article_id}', 'ForumController@article');
  Route::post('/forum/update_article', 'ForumController@update_article');
  Route::get('/deleteforum/{id}', 'ForumController@deleteforum');

  Route::get('/casts/deleteNotifications/', 'CastsController@deleteNotifications');    

  Route::get('/resources/categoryItemsAjax/{id}', 'ResourcesController@categoryItemsAjax');


  Route::get('/user/getUserPermission', 'UserController@getUserPermission');

  



    Route::get('/forum/commentrepliesajax/{comment_id}', 'ForumController@commentrepliesajax');

    Route::get('/forum/commentrepliesajaxreadmore/{comment_id}/{id}', 'ForumController@commentrepliesajaxreadmore');

    Route::get('/casts/homepage/{language_id}', 'CastsController@homepage');    
    Route::get('/casts/homepageMore/{language_id}/{id}', 'CastsController@homepageMore');   
    Route::get('/casts/GetNews/{language_id}/{id}', 'CastsController@GetNews');

     



    Route::get('/forum/readMore/{category_id}/{id}', 'ForumController@readMoreArticles');

    //cast
  //  Route::get('/get_home_json/{id}', 'CastsController@homeJson');
    Route::get('/casts/videosDataLoadMore/{video_id}', 'CastsController@videosDataLoadMore');
    Route::get('/casts/videosDataRefresh/{video_id}', 'CastsController@videosDataRefresh');
    Route::get('/casts/videosData/', 'CastsController@videosData');
    Route::get('/casts/loadCastAjax/{id}', 'CastsController@loadCastAjax');
    Route::post('/casts/ajaxaddComment', 'CastsController@ajaxaddComment');
    Route::get('/casts/deleteCommentajax/{id}', 'CastsController@deleteCommentajax');
    Route::post('/casts/updateCommentajax', 'CastsController@updateCommentajax');

    Route::get('/casts/getGroupajax/', 'CastsController@getGroupajax');
    Route::post('/casts/insertvideoajax', 'CastsController@insertvideoajax');

    Route::get('/casts/getNotificationscount/', 'CastsController@getNotificationscount');
    Route::get('/casts/getNotifications/', 'CastsController@getNotifications');
    Route::get('/casts/getNotificationView/{id}', 'CastsController@getNotificationView');
	
  Route::post('/casts/editorVideo', 'CastsController@editorVideo');
  

  Route::get('/resources/categoryItemsAjax/', 'ResourcesController@categoryItemsAjax');

  Route::get('/resources/categoryItemsAjaxByslug/{slug}', 'ResourcesController@categoryItemsAjaxByslug');


   Route::get('/coalitions/getCoalitionsAjax', 'coalitionsController@getCoalitionsAjax');

    Route::get('/coalitions/coalitionDeputies/{coalition_id}', 'coalitionsController@coalitionDeputies');

    Route::post('/news/addajax', 'NewsController@addajax');
    Route::get('/news/getdropdowndata', 'NewsController@getdropdowndata');
    Route::post('/news/update', 'NewsController@update');


    Route::post('User/updatePasswordajax', 'UserController@updatePasswordajax');


    Route::post('User/updateProfileAjax', 'UserController@updateProfileAjax');

    Route::get('/news/deleteajax/{news_id}', 'NewsController@deleteajax');

    Route::get('/forum/article/likes/{article_id}', 'ForumController@articleLikes');
    Route::get('/forum/comment/likes/{comment_id}', 'ForumController@commentLikes');
    Route::get('/forum/reply/likes/{reply_id}', 'ForumController@replyLikes');
    Route::get('/forum/reply/likes/{reply_id}', 'ForumController@replyLikes');



    
});
Route::post('forgot/password', 'Api\Auth\ForgotPasswordController')->name('forgot.password');
