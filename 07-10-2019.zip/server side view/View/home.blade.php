@extends('layouts.app')

@section('head')
<?php
$locale = app()->getLocale();
?>
@endsection

@section('style')
    <!--[if lt IE 9]>
<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<link href="css/facebook.css" rel="stylesheet">

@endsection

@section('content')
    <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
    <script type="text/javascript">
            $(function(){
                $('[data-toggle=offcanvas]').click(function() {
                    $(this).toggleClass('visible-xs text-center');
                    $(this).find('i').toggleClass('fa-chevron-right fa-chevron-left');
                    $('.row-offcanvas').toggleClass('active');
                    $('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
                    $('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
                    $('#btnShow').toggle();
                });
       
                $('.category').click(function(){
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        beforeSend:function(){
                          $('#loading').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                        },
                        success:function(data){
                            if(data){
                                $('#loading').modal('hide');
                                if(data['articles'].length > 9){
                                    $('#read_more').attr('href', '/forum/readMore/'+data.articles['9'].category_id + '/'+ data.articles['9'].id);
                                    $('#read_more').html('{{__('discussion.more_discussions')}}');
                                }else{
                                    $('#read_more').attr('href', '#');
                                    $('#read_more').html('');
                                
                                }
                                var cat_title=$('#cat_title');
                                var category_title=$('#category_title');
                                var lang = '<?php echo $locale ?>';
                                cat_title.empty();
                                category_title.empty();
                                if(lang=="en") {
                                    cat_title.append(
                                        data.category.en_title
                                    );
                                    category_title.append(
                                        data.category.en_title
                                    );
                                }
                                else if(lang=="da") {
                                    cat_title.append(
                                        data.category.da_title
                                    );
                                    category_title.append(
                                        data.category.da_title
                                    );
                                }
                                else{
                                    cat_title.append(
                                        data.category.ps_title
                                    );
                                    category_title.append(
                                        data.category.ps_title
                                    );
                                }
                                var table = $('#articles');
                                table.empty();
                            
                                $.each(data.articles, function (index, value) {
                                    var name="";
                                    var last_name="";
                                    if(value["user"]) {
                                        name = value["user"]["name"];
                                        last_name = value["user"]["last_name"];
                                    }
                                    
                                    var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==value.user_id){
                                            hiddenClass="";
                                        }
                                    
                                    table.append(
                                        '<tr>' +
                                        '<td>' +
                                        '<a class="article" href="forum/article/'+value.id+'">' +
                                        '<i class="fa fa-fw fa-file-text-o" aria-hidden="true"></i>' + value.title +
                                        '</a>' +
                                        '</td>' +
                                        '<td style="color:gray; font-size:12px;">'+ value.created_at +'</td>' +
                                        '<td>' +
                                        
                                        '<a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '" style="color:#444; font-size: 12px;" target="_blank">'+
                                        '<i class="fa fa-fw fa-user-o" aria-hidden="true"></i>' + name + ' ' + last_name +
                                        '</a>' +
                                        '</td>' +
                                        '<td class="text-center '+hiddenClass+'">' +
                                        '<a class="del" href="/deleteforum/' + value.id + '">' +
                                        '<i class="fa fa-fw fa-trash-o" title="Delete this record"></i>' +
                                        '</a></td>' +
                                        '</tr>'
                                    );
                                });
                                $('input[name=category_id]').val(data.category.id);
                                $('#articleContents').show();
                                if(data['articles'].length>0) {
                                    //article content
                                    $('#article_title').html(data['articles'][0]['title']);
                                    $('#profile_image').attr("href", "/users/profile/ajax/" + data['articles'][0]['user_id']);
                                    if (data['articles'][0]['user']['image']) {
                                        $('#profile_link').attr('src', data['articles'][0]['user']['image']);
                                    } else {
                                        if (data['articles'][0]['user']['gender'] == 1) {
                                            $('#profile_link').attr('src', 'profile_pic/profile_simple.png');
                                        } else {
                                            $('#profile_link').attr('src', 'profile_pic/profile_simple_gril.png');
                                        }
                                    }
                                    $('#user_name').html(data['articles'][0]['user']['name'] + ' ' + data['articles'][0]['user']['last_name']);
                                    $('#created_at').html(data['articles'][0]['created_at']);
                                    $('#editArticle').attr('href', '/forum/editarticle/' + data['articles'][0]['id']);

                                    if (data['articles'][0]['user']['id'] == '{{Auth::user()->id}}' || '{{Auth::user()->user_type}}' == 1) {
                                        $('#editArticle').removeClass('hidden');
                                    } else {
                                        $('#editArticle').addClass('hidden');
                                    }

                                    $('#article_body').html(data['articles'][0]['body']);
                                    if (data['articles'][0]['attachment'].length > 1) {
                                        $('#article_attachment').html('<a href="' + data['articles'][0]['attachment'] + '" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang("discussion.attached_file")</a>');
                                    } else {
                                        $('#article_attachment').html('');
                                    }
                                    $('#article_id').parent().parent().parent().parent().show();

                                    //article comment, likes, replies count
                                    $('#like').attr('href', '/forum/article/like/' + data['articles'][0]['id']);
                                    $('#likesCount').html(data['articles'][0]['likes'].length);
                                    $('.likes').attr('href', '/forum/article/likes/'+data['articles'][0]['id']);
                                    
                                    //verify if the current user liked the article or not
                                        var liked = $.grep(data['articles'][0]['likes'], function (item) {
                                            return item.user_id == {{Auth::user()->id}};
                                        });
                                        if (liked.length) {
                                            $('#like_color').css({'color': '#0b97c4', 'font-size': '23px'});
                                        } else {
                                            $('#like_color').css({'color': '#32383e', 'font-size': '20px'});
                                        }

                                    $('#commentCount').html(data['articles'][0]['comments'].length);

                                    $('#replyCount').html(data['articles'][0]['replies'].length);

                                    //comment and replies
                                    $('#article_id').attr('value', data['articles'][0]['id']);
                                    var commentContents = '';
                                    $.each(data.articles[0].comments, function (index, value) {
                                        commentContents += '<li class="media countable">' +
                                            '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                        if (value.user.image) {
                                            commentContents += '<img class="media-object img-circle" src="' + value.user.image + '" alt="profile">';

                                        } else {
                                            if (value.user.gender == 1) {
                                                commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                            } else {
                                                commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                            }
                                        }
                                        var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==value.user_id){
                                            hiddenClass="";
                                        }
                                        
                                        commentContents += '    </a>\n' +
                                            '    <div class="media-body">\n' +
                                            '        <div class="well well-sm">\n' +
                                            '            <table width="100%">\n' +
                                            '               <tr>\n' +
                                            '                   <td>\n' +
                                            '                       <h5 class="media-heading text-uppercase reviews">' + value["user"]["name"] + ' ' + value["user"]["last_name"] + '</h5>\n' +
                                            '                   </td>\n' +
                                            '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                            '                       <a class="fa fa-edit editComment '+ hiddenClass +'" href="forum/edit_comment/' + value.id + '"></a>\n' +
                                            '                       <a class="fa fa-fw fa-trash-o deleteComment '+ hiddenClass +'" href="/forum/delete_usercomment/' + value.id + '"></a>\n' +
                                            '                   </td>\n' +
                                            '               </tr>\n' +
                                            '            </table>' +
                                            '            <ul class="media-date text-uppercase reviews list-inline">\n' +
                                            '                <li style="color: #0b97c4; font-size: 14px;">' + value.created_at + '</li>\n' +
                                            '            </ul>\n' +
                                            '            <p class="media-comment" id="comment' + value.id + '">\n' +
                                            value.reply +
                                            '            </p>\n' +
                                            '            <table width="100%">\n' +
                                            '                <tr>\n' +
                                            '                    <td style="@if($locale=="en") text-align: left; @else text-align: right; @endif">\n' +
                                            '                        <a class="fa fa-thumbs-o-up likeComment" href="forum/article/likecomment/' + value.id + '" \n';

                                        //verify if the current user liked the comment of not
                                        var liked = $.grep(value.likes, function (item) {
                                            return item.user_id == {{Auth::user()->id}};
                                        });
                                        if (liked.length) {
                                            commentContents += 'style="color: #0b97c4; font-size: 18px;"> </a>';
                                        } else {
                                            commentContents += 'style="color: #32383e; font-size: 16px;"> </a>';
                                        }

                                        commentContents += ' {{__("discussion.like")}}| <a class="commentLikes" href="/forum/comment/likes/'+value.id+'"><span id="commentlikesCount">' + value.likes.length + '</span></a>\n' +
                                            '                    </td>\n' +
                                            '                    <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif">\n' +
                                            '                        <a class="fa fa-reply" data-toggle="collapse" href="#demo' + value.id + '" id="reply"> {{__("discussion.reply")}} | </a> <span class="rCount">' + value.replies.length + '</span>\n' +
                                            '                    </td>\n' +
                                            '                </tr>\n' +
                                            '            </table>\n' +
                                            '            <div id="demo' + value.id + '" class="collapse">\n' +
                                            '                <hr>\n' +
                                            '                <form action="/replytocomment_add" method="post" class="replyform form-inline">\n' +
                                            '                    {{csrf_field()}}\n' +
                                            '                    <input type="hidden" name="comment_id" value="' + value.id + '">\n' +
                                            '                    <input type="hidden" name="article_id" value="' + data['articles'][0]['id'] + '">\n' +
                                            '                    <textarea class="form-control" style="width:78%;" placeholder="{{__("discussion.replytothiscomment")}}" name="content" rows="1"></textarea>\n' +
                                            '                    <button type="submit" class="btn btn-default">{{__('discussion.submitreply')}}</button>\n' +
                                            '                </form>\n' +
                                            '                <hr>\n';

                                        $.each(value.replies, function (index, reply) {
                                            commentContents += '<ul class="media-list">\n' +
                                                '                    <li class="media media-replied">\n' +
                                                '                        <a class="pull-left profile_image" href="/users/profile/ajax/' + reply.user_id + '}}">\n';
                                            if (reply.user.image) {
                                                commentContents += '<img class="media-object img-circle" src="' + reply.user.image + '" alt="profile">';

                                            } else {
                                                if (reply.user.gender == 1) {
                                                    commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                                } else {
                                                    commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                                }
                                            }
                                            var hiddenClass="hidden";
                                            if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==reply.user_id){
                                                    hiddenClass="";
                                            }
                                            commentContents += '  </a>\n' +
                                                '                        <div class="media-body">\n' +
                                                '                            <div class="well well-sm" style="background-color: white">\n' +
                                                '            <table width="100%">\n' +
                                                '               <tr>\n' +
                                                '                   <td>\n' +
                                                '                       <h5 class="media-heading text-uppercase reviews">' + reply["user"]["name"] + ' ' + reply["user"]["last_name"] + '</h5>\n' +
                                                '                   </td>\n' +
                                                '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                                '                       <a class="fa fa-edit editReply '+ hiddenClass +'" href="/edit/your/reply/' + reply.id + '"></a>\n' +
                                                '                       <a class="fa fa-fw fa-trash-o deleteReply '+ hiddenClass +'" href="/delete/your/reply/' + reply.id + '"></a>\n' +
                                                '                   </td>\n' +
                                                '               </tr>\n' +
                                                '            </table>' +
                                                '                                <ul class="media-date text-uppercase reviews list-inline">\n' +
                                                '                                    <li style="color: #0b97c4; font-size: 14px;">' + reply.reply_date + '</li>\n' +
                                                '                                </ul>\n' +
                                                '                                <p class="media-comment" id="reply' + reply.id + '">\n' +
                                                reply.content +
                                                '                                </p>\n' +
                                                '                                <a class="fa fa-thumbs-o-up likeReply" href="forum/article/likereply/' + reply.id + '"\n';
                                            //verify if the current user liked the reply or not
                                            var liked = $.grep(reply.likes, function (item) {
                                                return item.user_id == {{Auth::user()->id}};
                                            });
                                            if (liked.length) {
                                                commentContents += 'style="color: #0b97c4; font-size: 18px;"> </a>';
                                            } else {
                                                commentContents += 'style="color: #32383e; font-size: 16px;"> </a>';
                                            }

                                            commentContents += ' {{__("discussion.like")}} | <a class="replyLikes" href="/forum/reply/likes/'+reply.id+'"><span>' + reply.likes.length + '</span></a>' +
                                                '                                \n' +
                                                '                            </div>\n' +
                                                '                        </div>\n' +
                                                '                    </li>\n' +
                                                '                </ul>\n';
                                        });

                                        commentContents += '            </div>\n' +
                                            '        </div>\n' +
                                            '    </div>\n' +
                                            '</li>\n';
                                    });
                                    
                                    if (data.articles[0].comments.length > 0) {
                                        $('#comments').html(commentContents);
                                    } else {
                                        $('#comments').html('');
                                    }
                                  var list = $("#comments li.countable");
                                  var numToShow = 5;
                                  var button = $("#next");
                                  var numInList = list.length;
                                  list.hide();
                                  button.hide();
                                  if (numInList > numToShow) {
                                    button.show();
                                  }
                                  list.slice(0, numToShow).show();
                                }else{
                                    $('#articleContents').hide();
                                }
                                
                            }else{
                                alert("You don't have permission to access this category.");
                            }
                        },
                        error: function (data) {
                            $('#loading').modal('hide');
                            alert('Failed to load!');
                        }
                    });
                    return false;
                    // or alert($(this).hash();
                });
                $('#app').on('click', '.profile_image', function(){
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        beforeSend:function(){
                          $('#loading').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                        },
                        success:function(data){
                            if(data){
                                $('#loading').modal('hide');
                                var user_profile= '<style>\n' +
                                    '.modal {overflow-y: auto !important;}'+
                                    '        .card {\n' +
                                    '            padding-top: 20px;\n' +
                                    '            margin: 10px 0 20px 0;\n' +
                                    '            background-color: rgba(214, 224, 226, 0.2);\n' +
                                    '            border-top-width: 0;\n' +
                                    '            border-bottom-width: 2px;\n' +
                                    '            -webkit-border-radius: 3px;\n' +
                                    '            -moz-border-radius: 3px;\n' +
                                    '            border-radius: 3px;\n' +
                                    '            -webkit-box-shadow: none;\n' +
                                    '            -moz-box-shadow: none;\n' +
                                    '            box-shadow: none;\n' +
                                    '            -webkit-box-sizing: border-box;\n' +
                                    '            -moz-box-sizing: border-box;\n' +
                                    '            box-sizing: border-box;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading {\n' +
                                    '            padding: 0 20px;\n' +
                                    '            margin: 0;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading.simple {\n' +
                                    '            font-size: 20px;\n' +
                                    '            font-weight: 300;\n' +
                                    '            color: #777;\n' +
                                    '            border-bottom: 1px solid #e5e5e5;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading.image img {\n' +
                                    '            display: inline-block;\n' +
                                    '            width: 46px;\n' +
                                    '            height: 46px;\n' +
                                    '            margin-right: 15px;\n' +
                                    '            vertical-align: top;\n' +
                                    '            border: 0;\n' +
                                    '            -webkit-border-radius: 50%;\n' +
                                    '            -moz-border-radius: 50%;\n' +
                                    '            border-radius: 50%;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading.image .card-heading-header {\n' +
                                    '            display: inline-block;\n' +
                                    '            vertical-align: top;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading.image .card-heading-header h3 {\n' +
                                    '            margin: 0;\n' +
                                    '            font-size: 14px;\n' +
                                    '            line-height: 16px;\n' +
                                    '            color: #262626;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-heading.image .card-heading-header span {\n' +
                                    '            font-size: 12px;\n' +
                                    '            color: #999999;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-body {\n' +
                                    '            padding: 0 20px;\n' +
                                    '            margin-top: 20px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-media {\n' +
                                    '            padding: 0 20px;\n' +
                                    '            margin: 0 -14px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-media img {\n' +
                                    '            max-width: 100%;\n' +
                                    '            max-height: 100%;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-actions {\n' +
                                    '            min-height: 30px;\n' +
                                    '            padding: 0 20px 20px 20px;\n' +
                                    '            margin: 20px 0 0 0;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-comments {\n' +
                                    '            padding: 20px;\n' +
                                    '            margin: 0;\n' +
                                    '            background-color: #f8f8f8;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-comments .comments-collapse-toggle {\n' +
                                    '            padding: 0;\n' +
                                    '            margin: 0 20px 12px 20px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card .card-comments .comments-collapse-toggle a,\n' +
                                    '        .card .card-comments .comments-collapse-toggle span {\n' +
                                    '            padding-right: 5px;\n' +
                                    '            overflow: hidden;\n' +
                                    '            font-size: 12px;\n' +
                                    '            color: #999;\n' +
                                    '            text-overflow: ellipsis;\n' +
                                    '            white-space: nowrap;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card-comments .media-heading {\n' +
                                    '            font-size: 13px;\n' +
                                    '            font-weight: bold;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people {\n' +
                                    '            position: relative;\n' +
                                    '            display: inline-block;\n' +
                                    '            width: 170px;\n' +
                                    '            height: 300px;\n' +
                                    '            padding-top: 0;\n' +
                                    '            margin-left: 20px;\n' +
                                    '            overflow: hidden;\n' +
                                    '            vertical-align: top;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people:first-child {\n' +
                                    '            margin-left: 0;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-top {\n' +
                                    '            position: absolute;\n' +
                                    '            top: 0;\n' +
                                    '            left: 0;\n' +
                                    '            display: inline-block;\n' +
                                    '            width: 170px;\n' +
                                    '            height: 150px;\n' +
                                    '            background-color: #ffffff;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-top.green {\n' +
                                    '            background-color: #53a93f;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-top.blue {\n' +
                                    '            background-color: #427fed;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-info {\n' +
                                    '            position: absolute;\n' +
                                    '            top: 150px;\n' +
                                    '            display: inline-block;\n' +
                                    '            width: 100%;\n' +
                                    '            height: 101px;\n' +
                                    '            overflow: hidden;\n' +
                                    '            background: #ffffff;\n' +
                                    '            -webkit-box-sizing: border-box;\n' +
                                    '            -moz-box-sizing: border-box;\n' +
                                    '            box-sizing: border-box;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-info .title {\n' +
                                    '            display: block;\n' +
                                    '            margin: 8px 14px 0 14px;\n' +
                                    '            overflow: hidden;\n' +
                                    '            font-size: 16px;\n' +
                                    '            font-weight: bold;\n' +
                                    '            line-height: 18px;\n' +
                                    '            color: #404040;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-info .desc {\n' +
                                    '            display: block;\n' +
                                    '            margin: 8px 14px 0 14px;\n' +
                                    '            overflow: hidden;\n' +
                                    '            font-size: 12px;\n' +
                                    '            line-height: 16px;\n' +
                                    '            color: #737373;\n' +
                                    '            text-overflow: ellipsis;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.people .card-bottom {\n' +
                                    '            position: absolute;\n' +
                                    '            bottom: 0;\n' +
                                    '            left: 0;\n' +
                                    '            display: inline-block;\n' +
                                    '            width: 100%;\n' +
                                    '            padding: 10px 20px;\n' +
                                    '            line-height: 29px;\n' +
                                    '            text-align: center;\n' +
                                    '            -webkit-box-sizing: border-box;\n' +
                                    '            -moz-box-sizing: border-box;\n' +
                                    '            box-sizing: border-box;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard {\n' +
                                    '            position: relative;\n' +
                                    '            padding-top: 0;\n' +
                                    '            overflow: hidden;\n' +
                                    '            text-align: center;\n' +
                                    '            background-color: rgba(214, 224, 226, 0.2);\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .cardheader {\n' +
                                    '            background: url("http://lorempixel.com/850/280/nature/4/");\n' +
                                    '            background-size: cover;\n' +
                                    '            height: 135px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .avatar {\n' +
                                    '            position: relative;\n' +
                                    '            top: -50px;\n' +
                                    '            margin-bottom: -50px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .avatar img {\n' +
                                    '            width: 170px;\n' +
                                    '            height: 170px;\n' +
                                    '            max-width: 170px;\n' +
                                    '            max-height: 170px;\n' +
                                    '            -webkit-border-radius: 50%;\n' +
                                    '            -moz-border-radius: 50%;\n' +
                                    '            border-radius: 50%;\n' +
                                    '            border: 5px solid rgba(255,255,255,0.5);\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .info {\n' +
                                    '            padding: 4px 8px 10px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .info .title {\n' +
                                    '            margin-bottom: 4px;\n' +
                                    '            font-size: 24px;\n' +
                                    '            line-height: 1;\n' +
                                    '            color: #262626;\n' +
                                    '            vertical-align: middle;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .info .desc {\n' +
                                    '            overflow: hidden;\n' +
                                    '            font-size: 12px;\n' +
                                    '            line-height: 20px;\n' +
                                    '            color: #737373;\n' +
                                    '            text-overflow: ellipsis;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '        .card.hovercard .bottom {\n' +
                                    '            padding: 0 20px;\n' +
                                    '            margin-bottom: 17px;\n' +
                                    '        }\n' +
                                    '\n' +
                                    '    </style>\n' +
                                    '        <div class="col-md-12">\n' +
                                    '        <div class="card hovercard">\n' +
                                    '          <div class="cardheader">\n' +
                                    '\n' +
                                    '          </div>\n' +
                                    '          <div class="avatar">\n';

                                if(data.user.image != null){
                                    user_profile += '<img alt="" src="/'+data.user.image +'">\n';
                                } else {
                                    if (data.user.gender == 1) {
                                        user_profile += '<img alt="" src="/profile_pic/profile_simple.png">\n';
                                    } else {
                                        user_profile += '<img alt="" src="/profile_pic/profile_simple_gril.png">\n';
                                    }
                                }

                                user_profile += '</div>\n' +
                                    '          <div class="info">\n' +
                                    '            <div class="title">\n' +
                                    '              <a target="_blank" href="javascript:avoid">'+ data.user.name +' '+ data.user.last_name +'</a>\n' +
                                    '            </div>\n' +
                                    '            <div class="desc">\n' +
                                    data.userType +
                                    '            </div>\n' +
                                    '            <div class="desc">\n' +
                                    data.user.email +
                                    '            </div>\n' +
                                    '            <div class="desc">'+data.user.mobile+'</div>\n' +
                                    '          </div>\n' +
                                    '          \n' +
                                    '        </div>\n' +
                                    '\n' +
                                    '      </div>'+
                                    '<table class="table table-striped"  colspan="3">\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td width="200px">\n' +
                                    '      <i class="fa fa-user-o" aria-hidden="true"></i>\n' +
                                    '      {{ __("nav.user_id") }}\n' +
                                    '    </td>\n' +
                                    '      <td>'+ data.user.id +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td width="200px">\n' +
                                    '        <i class="fa fa-user-o" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.name") }}\n' +
                                    '        </td>\n' +
                                    '      <td> '+ data.user.name +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td>\n' +
                                    '        <i class="fa fa-envelope-o" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.email") }}\n' +
                                    '        </td>\n' +
                                    '      <td>'+ data.user.email  +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td>\n' +
                                    '        <i class="fa fa-phone" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.contactnumber") }}\n' +
                                    '        </td>\n' +
                                    '      <td>'+ data.user.mobile +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td>\n' +
                                    '        <i class="fa fa-clock-o" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.registrationdate") }}\n' +
                                    '        </td>\n' +
                                    '      <td>'+ data.user.created_at +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td>\n' +
                                    '        <i class="fa fa-user-circle-o" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.usertype") }}\n' +
                                    '        </td>\n' +
                                    '      <td>\n' +
                                    data.userType +
                                    '      </td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td>\n' +
                                    '        <i class="fa fa-users" aria-hidden="true"></i>\n' +
                                    '        {{ __("nav.coalitions") }}\n' +
                                    '      </td>\n' +
                                    '      <td>\n' +
                                    '\n';
                                $.each(data.coalitions, function (key, value) {
                                    if('{{$locale}}'=="en"){
                                        user_profile+=value.en_title + '<br>';
                                    }else if('{{$locale}}'=="da"){
                                        user_profile+=value.da_title + '<br>';
                                    }else{
                                        user_profile+=value.ps_title + '<br>';
                                    }
                                });
                                user_profile+='      </td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td class="details">{{__('nav.total_posts')}}</td>\n' +
                                    '      <td>'+ data.user.articles.length +'</td>\n' +
                                    '    </tr>\n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td class="details">{{__('nav.total_comments')}}</td>\n' +
                                    '      <td>'+ data.user.comments.length +'</td>\n' +
                                    '    </tr>     \n' +
                                    '\n' +
                                    '    <tr>\n' +
                                    '      <td class="details">{{__('nav.total_replies')}}</td>\n' +
                                    '      <td>'+ data.user.replies.length +'</td>\n' +
                                    '    </tr>     \n' +
                                    '\n' +
                                    '  </table>';
                                    
                                $('#userModal').modal('show');
                                $('#user_profile').html(user_profile);
                                

                            }else{
                                alert("You don't have permission to access this category.");
                            }
                        },
                        error: function (data) {
                            $('#loading').modal('hide');
                            alert('Failed to load!');
                        }
                    });
                    return false;
                    // or alert($(this).hash();
                });
                $('#editArticle').click(function(){
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        success:function(data){
                            if(data){
                                $('#editArticleDiv').modal('show');
                                $('#edited_article_id').val(data.id);
                                $('#edited_title').val(data.title);
                                $('#edited_body').summernote('destroy');
                                $('#edited_body').val(data.body);
                                $('#edited_body').summernote('code');

                                if(data.attachment){
                                    $('#exist_attachment').removeClass('hidden');
                                }else {
                                    $('#exist_attachment').addClass('hidden');
                                }
                                $('#edited_attachment').val(data.attachment);
                            }else{
                                alert("You don't have permission to edit this article!");
                            }
                        },
                        error: function (data) {
                            alert('Looking something went wrong!');
                        }
                    });
                    return false;
                });
                $( '#edited_article' ).on( 'submit', function(e) {
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/forum/update_article") }}',
                        type: 'POST',
                        data: formData,
                        beforeSend:function(){
                          $('#loading').modal({
                                backdrop: 'static',
                                keyboard: false
                           });
                           $('#editArticleDiv').modal("hide");
                        },
                        success: function (data) {
                                $('#loading').modal('hide');
                                //article content
                                $('#article_title').html(data.title);

                                $('#article_body').html(data['body']);
                                if(data['attachment'].length>1){
                                    $('#article_attachment').html('<a href="'+ data['attachment'] +'" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang("discussion.attached_file")</a>');
                                }else{
                                    $('#article_attachment').html('');
                                }
                        },
                        error: function (data) {
                            $('#loading').modal('hide');
                            alert('Looking something went wrong!');
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
                });
                $( '#add_article' ).on( 'submit', function(e) {
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/forum/save_article") }}',
                        type: 'POST',
                        data: formData,
                        beforeSend:function(){
                          $('#loading').modal({
                                backdrop: 'static',
                                keyboard: false
                           });
                           $('#postModal').modal("hide");
                        },
                        success: function (data) {
                            if(data=="This discussion is already exists!"){
                                alert(data);
                            }else{
                                $('#loading').modal('hide');
                                $('#title').val('');
                                $('#body').summernote('destroy');
                                $('#body').val('');
                                $('#body').summernote('code');
        
                                $('#attachment').val('');
    
                                $('#postModal').modal("hide");
                            
                                /*
                                $('#article_delete_conformation').html('<div class="alert alert-success alert-dismissible">' +
                                    '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' +
                                    '<strong>Success!</strong> You have successfully added an article' +
                                    '</div>');
                                $('#article_delete_conformation').fadeIn('fast');
                                $('#article_delete_conformation').delay(3000).fadeOut('fast');
                                */
                                
                                var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==data.user_id){
                                            hiddenClass="";
                                        }
    
                                $('#articles').prepend(
                                    '<tr>' +
                                    '<td>' +
                                    '<a class="article" href="forum/article/'+data.id+'">' +
                                    '<i class="fa fa-fw fa-file-text-o" aria-hidden="true"></i>' + data.title +
                                    '</a>' +
                                    '</td>' +
                                    '<td style="color:gray; font-size:12px;">'+ data.created_at +'</td>' +
                                    '<td>' +
                                    '<a class="profile_image" href="/users/profile/ajax/' + data.user_id + '" style="color:#444; font-size: 12px;" target="_blank">' +
                                    '<i class="fa fa-fw fa-user-o" aria-hidden="true"></i>' + data.user.name + ' ' + data.user.last_name +
                                    '</a>' +
                                    '</td>' +
                                    '<td class="text-center '+hiddenClass+'">' +
                                    '<a class="del" href="/deleteforum/' + data.id + '">' +
                                    '<i class="fa fa-fw fa-trash-o" title="Delete this record"></i>' +
                                    '</a></td>' +
                                    '</tr>'
                                );
                                $('#article_id').val(data.id);
    
                                $('#comments').html('');
                                //article content
                                $('.likes').attr('href', '/forum/article/likes/'+data.id);
                                $('#article_title').html(data.title);
                                $('#profile_image').attr("href", "/users/profile/ajax/"+data['user_id']);
                                if(data['user']['image']){
                                    $('#profile_link').attr('src', data['user']['image']);
                                }else{
                                    if(data['user']['gender']==1){
                                        $('#profile_link').attr('src', 'profile_pic/profile_simple.png');
                                    }else{
                                        $('#profile_link').attr('src', 'profile_pic/profile_simple_gril.png');
                                    }
                                }
                                $('#user_name').html(data['user']['name'] + ' ' + data['user']['last_name']);
                                $('#created_at').html(data['created_at']);
                                $('#editArticle').attr('href', '/forum/editarticle/'+data['id']);
    
                                if(data['user']['id'] == '{{Auth::user()->id}}' || '{{Auth::user()->user_type}}'==1){
    
                                }else{
                                    $('#editArticle').addClass('hidden');
                                }
    
                                $('#article_body').empty();
                                $('#article_body').html(data['body']);
                                if(data['attachment'].length>1){
                                    $('#article_attachment').html('<a href="'+ data['attachment'] +'" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang("discussion.attached_file")</a>');
                                }else{
                                    $('#article_attachment').html('');
                                }
    
                                //article comment, likes, replies count
                                $('#like').attr('href', '/forum/article/like/'+ data['id']);
                                $('#likesCount').html(data['likes'].length)
    
                                $('#commentCount').html(data['comments'].length);
    
                                $('#replyCount').html(data['replies'].length);
                            }
                        },
                        error: function (data) {
                            $('#loading').modal('hide');
                            alert('Looking something went wrong!');
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
                });

                //deleteing article
                $('#articles').on('click', '.del', function(e){
                    e.preventDefault();
                    var record=$(this).parent().parent();
                    var url=$(this).attr('href');
                    if (confirm("Are you sure?")) {
                        $.ajax({
                            url: url,
                            type: 'get',
                            beforeSend:function(){
                              $('#loading').modal({
                                    backdrop: 'static',
                                    keyboard: false
                               });
                            },
                            success: function (data) {
                                if (data==='') {
                                    alert("You don't have permission to delete this item!");
                                } else if(data==='not exist'){
                                    alert('This item is not currently exist!')
                                } else {
                                    /*
                                    $('#article_delete_conformation').html('<div class="alert alert-success alert-dismissible">' +
                                        '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>' +
                                        '<strong>Success!</strong> You have successfully deleted '+ data.title + ' item!' +
                                        '</div>');
                                    $('#article_delete_conformation').fadeIn('fast');
                                    $('#article_delete_conformation').delay(3000).fadeOut('fast');
                                    */
                                    record.addClass("hidden");

                                }
                                $('#loading').modal('hide');

                                //article content
                                $('#article_title').html(data['articles']['title']);
                                $('#profile_image').attr("href", "/users/profile/ajax/"+data['articles']['user_id']);
                                if(data['articles']['user']['image']){
                                    $('#profile_link').attr('src', data['articles']['user']['image']);
                                }else{
                                    if(data['articles']['user']['gender']==1){
                                        $('#profile_link').attr('src', 'profile_pic/profile_simple.png');
                                    }else{
                                        $('#profile_link').attr('src', 'profile_pic/profile_simple_gril.png');
                                    }
                                }
                                $('#user_name').html(data['articles']['user']['name'] + ' ' + data['articles']['user']['last_name']);
                                $('#created_at').html(data['articles']['created_at']);
                                $('#editArticle').attr('href', '/forum/editarticle/'+data['articles']['id']);

                                if(data['articles']['user']['id'] == '{{Auth::user()->id}}' || '{{Auth::user()->user_type}}'==1){

                                }else{
                                    $('#editArticle').addClass('hidden');
                                }

                                $('#article_body').empty();
                                $('#article_body').html(data['articles']['body']);
                                if(data['articles']['attachment'].length>1){
                                    $('#article_attachment').html('<a href="'+ data['articles']['attachment'] +'" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang("discussion.attached_file")</a>');
                                }else{
                                    $('#article_attachment').html('');
                                }

                                //article comment, likes, replies count
                                $('#like').attr('href', '/forum/article/like/'+ data['articles']['id']);
                                $('#likesCount').html(data['articles']['likes'].length);
                                $('.likes').attr('href', '/forum/article/likes/'+data['articles']['id']);
                                
                                //verify if the current user liked the article or not
                                        var liked = $.grep(data['articles']['likes'], function (item) {
                                            return item.user_id == {{Auth::user()->id}};
                                        });
                                        if (liked.length) {
                                            $('#like_color').css({'color': '#0b97c4', 'font-size': '23px'});
                                        } else {
                                            $('#like_color').css({'color': '#32383e', 'font-size': '20px'});
                                        }

                                $('#commentCount').html(data['articles']['comments'].length);

                                $('#replyCount').html(data['articles']['replies'].length);

                                //comment and replies
                                $('#article_id').attr('value', data['articles']['id']);
                                var commentContents='';
                                $.each(data.articles.comments, function (index , value) {
                                    commentContents+= '<li class="media countable">' +
                                        '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                    if(value.user.image){
                                        commentContents+='<img class="media-object img-circle" src="'+ value.user.image +'" alt="profile">';

                                    }else{
                                        if(value.user.gender==1){
                                            commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                        }else{
                                            commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                        }
                                    }
                                    
                                    var hiddenClass="hidden";
                                    if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==value.user_id){
                                            hiddenClass="";
                                        }
                                        
                                    commentContents+='    </a>\n' +
                                        '    <div class="media-body">\n' +
                                        '        <div class="well well-sm">\n' +
                                        '            <table width="100%">\n' +
                                        '               <tr>\n' +
                                        '                   <td>\n' +
                                        '                       <h5 class="media-heading text-uppercase reviews">'+value["user"]["name"]+ ' ' + value["user"]["last_name"]+'</h5>\n' +
                                        '                   </td>\n' +
                                        '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                        '                       <a class="fa fa-edit editComment '+ hiddenClass +'" href="forum/edit_comment/'+ value.id +'"></a>\n' +
                                        '                       <a class="fa fa-fw fa-trash-o deleteComment '+ hiddenClass +'" href="/forum/delete_usercomment/' + value.id+'"></a>\n' +
                                        '                   </td>\n' +
                                        '               </tr>\n' +
                                        '            </table>'+
                                        '            <ul class="media-date text-uppercase reviews list-inline">\n' +
                                        '                <li style="color: #0b97c4; font-size: 14px;">'+ value.created_at +'</li>\n' +
                                        '            </ul>\n' +
                                        '            <p class="media-comment" id="comment'+value.id+'">\n' +
                                        value.reply +
                                        '            </p>\n' +
                                        '            <table width="100%">\n' +
                                        '                <tr>\n' +
                                        '                    <td style="@if($locale=="en") text-align: left; @else text-align: right; @endif">\n' +
                                        '                        <a class="fa fa-thumbs-o-up likeComment" href="forum/article/likecomment/' + value.id+ '" \n';

                                    //verify if the current user liked the comment of not
                                    var liked = $.grep(value.likes, function(item) {
                                        return item.user_id == {{Auth::user()->id}};
                                    });
                                    if(liked.length){
                                        commentContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                    }else{
                                        commentContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                    }

                                    commentContents+= ' {{__("discussion.like")}}| <a class="commentLikes" href="/forum/comment/likes/'+value.id+'"><span id="commentlikesCount">' + value.likes.length + '</span></a>\n' +
                                        '                        \n' +
                                        '                    </td>\n' +
                                        '                    <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif">\n' +
                                        '                        <a class="fa fa-reply" data-toggle="collapse" href="#demo'+value.id+'" id="reply"> {{__("discussion.reply")}} | </a> <span class="rCount">' + value.replies.length + '</span>\n' +
                                        '                    </td>\n' +
                                        '                </tr>\n' +
                                        '            </table>\n' +
                                        '            <div id="demo'+value.id+'" class="collapse">\n' +
                                        '                <hr>\n' +
                                        '                <form action="/replytocomment_add" method="post" class="replyform form-inline">\n' +
                                        '                    {{csrf_field()}}\n' +
                                        '                    <input type="hidden" name="comment_id" value="'+value.id+'">\n' +
                                        '                    <input type="hidden" name="article_id" value="'+data['articles']['id']+'">\n' +
                                        '                    <textarea class="form-control" style="width:78%;" placeholder="{{__("discussion.replytothiscomment")}}" name="content" rows="1"></textarea>\n' +
                                        '                    <button type="submit" class="btn btn-default">{{__('discussion.submitreply')}}</button>\n' +
                                        '                </form>\n' +
                                        '                <hr>\n';

                                    $.each(value.replies, function (index, reply) {
                                        commentContents+=  '<ul class="media-list">\n' +
                                            '                    <li class="media media-replied">\n' +
                                            '                        <a class="pull-left profile_image" href="/users/profile/ajax/' + reply.user_id +'}}">\n';
                                        if(reply.user.image){
                                            commentContents+='<img class="media-object img-circle" src="'+ reply.user.image +'" alt="profile">';

                                        }else{
                                            if(reply.user.gender==1){
                                                commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                            }else{
                                                commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                            }
                                        }
                                        var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==reply.user_id){
                                                hiddenClass="";
                                        }
                                        commentContents+='  </a>\n' +
                                            '                        <div class="media-body">\n' +
                                            '                            <div class="well well-sm" style="background-color: white">\n' +
                                            '            <table width="100%">\n' +
                                            '               <tr>\n' +
                                            '                   <td>\n' +
                                            '                       <h5 class="media-heading text-uppercase reviews">'+reply["user"]["name"]+ ' ' + reply["user"]["last_name"]+'</h5>\n' +
                                            '                   </td>\n' +
                                            '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                            '                       <a class="fa fa-edit editReply '+ hiddenClass +'" href="/edit/your/reply/'+ reply.id +'"></a>\n' +
                                            '                       <a class="fa fa-fw fa-trash-o deleteReply '+ hiddenClass +'" href="/delete/your/reply/' + reply.id+'"></a>\n' +
                                            '                   </td>\n' +
                                            '               </tr>\n' +
                                            '            </table>'+
                                            '                                <ul class="media-date text-uppercase reviews list-inline">\n' +
                                            '                                    <li style="color: #0b97c4; font-size: 14px;">'+reply.reply_date+'</li>\n' +
                                            '                                </ul>\n' +
                                            '                                <p class="media-comment" id="reply'+reply.id+'">\n' +
                                            reply.content +
                                            '                                </p>\n' +
                                            '                                <a class="fa fa-thumbs-o-up likeReply" href="forum/article/likereply/' + reply.id+'"\n' ;
                                        //verify if the current user liked the reply or not
                                        var liked = $.grep(reply.likes, function(item) {
                                            return item.user_id == {{Auth::user()->id}};
                                        });
                                        if(liked.length){
                                            commentContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                        }else{
                                            commentContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                        }

                                        commentContents+= ' {{__("discussion.like")}} | <a class="replyLikes" href="/forum/reply/likes/'+reply.id+'"><span>' + reply.likes.length + '</span></a>'+
                                            '                                \n' +
                                            '                            </div>\n' +
                                            '                        </div>\n' +
                                            '                    </li>\n' +
                                            '                </ul>\n';
                                    });

                                    commentContents+='            </div>\n' +
                                        '        </div>\n' +
                                        '    </div>\n' +
                                        '</li>\n';
                                });
                                if(data.articles.comments.length>0) {
                                    $('#comments').html(commentContents);
                                }else{
                                    $('#comments').html('');
                                }
                                var list = $("#comments li.countable");
                                  var numToShow = 5;
                                  var button = $("#next");
                                  var numInList = list.length;
                                  list.hide();
                                  button.hide();
                                  if (numInList > numToShow) {
                                    button.show();
                                  }
                                  list.slice(0, numToShow).show();
                            },
                            error: function (data) {
                                $('#loading').modal('hide');
                                alert('Failed to load!');
                            }
                        });
                    }
                    return false;
                    // or alert($(this).hash();
                });

                //like article
                $('#like').click(function(e){
                    e.preventDefault();
                    var url=$(this).attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            if (data.like==='liked') {
                                $('#like_color').css({'color': '#0b97c4', 'font-size': '25px'});
                                $('#likesCount').html(data.likes);
                            } else {
                                $('#like_color').css({'color': '#32383e', 'font-size': '22px'});
                                $('#likesCount').html(data.likes);
                            }
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });

                //comment to article
                $('#saveComment').on('submit', function(e){
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/forum/save_reply") }}',
                        type: 'post',
                        data: formData,
                        success: function (Rdata) {
                            let data=Rdata.comment;
                            if (data) {
                                commentContents="";
                                commentContents+= '<li class="media countable">' +
                                    '    <a class="pull-left profile_image" href="/users/profile/ajax/' + data.user_id + '">';
                                if(data.user.image){
                                    commentContents+='<img class="media-object img-circle" src="'+ data.user.image +'" alt="profile">';

                                }else{
                                    if(data.user.gender==1){
                                        commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    }else{
                                        commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                var hiddenClass="hidden";
                                if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==data.user_id){
                                            hiddenClass="";
                                        }
                                       

                                commentContents+='    </a>\n' +
                                    '    <div class="media-body">\n' +
                                    '        <div class="well well-sm">\n' +
                                    '            <table width="100%">\n' +
                                    '              <tr>\n' +
                                    '                 <td>\n' +
                                    '                    <h5 class="media-heading text-uppercase reviews">'+data["user"]["name"]+ ' ' + data["user"]["last_name"]+'</h5>\n' +
                                    '                 </td>\n' +
                                    '                 <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                    '                   <a class="fa fa-edit editComment '+ hiddenClass +'" href="forum/edit_comment/'+ data.id +'"></a>\n' +
                                    '                   <a class="fa fa-fw fa-trash-o deleteComment '+ hiddenClass +'" href="/forum/delete_usercomment/' + data.id+'"></a>\n' +
                                    '                 </td>\n' +
                                    '              </tr>\n' +
                                    '            </table>'+
                                    '            <ul class="media-date text-uppercase reviews list-inline">\n' +
                                    '                <li style="color: #0b97c4; font-size: 14px;">'+ data.created_at +'</li>\n' +
                                    '            </ul>\n' +
                                    '            <p class="media-comment" id="comment'+data.id+'">\n' +
                                    data.reply +
                                    '            </p>\n' +
                                    '            <table width="100%">\n' +
                                    '                <tr>\n' +
                                    '                    <td style="@if($locale=="en") text-align: left; @else text-align: right; @endif">\n' +
                                    '                        <a class="fa fa-thumbs-o-up likeComment" href="forum/article/likecomment/' + data.id+ '"\n';
                                //verify if the current user liked the comment of not
                                var liked = $.grep(data.likes, function(item) {
                                    return item.user_id == {{Auth::user()->id}};
                                });
                                if(liked.length){
                                    commentContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                }else{
                                    commentContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                }

                                commentContents+= ' {{__("discussion.like")}}| <a class="commentLikes" href="/forum/comment/likes/'+data.id+'"><span id="commentlikesCount">' + data.likes.length + '</span></a>\n' +
                                    '                        \n' +
                                    '                    </td>\n' +
                                    '                    <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif">\n' +
                                    '                        <a class="fa fa-reply" data-toggle="collapse" href="#demo'+data.id+'" id="reply"> {{__("discussion.reply")}} | </a> <span class="rCount">' + data.replies.length + '</span>\n' +
                                    '                    </td>\n' +
                                    '                </tr>\n' +
                                    '            </table>\n' +
                                    '            <div id="demo'+data.id+'" class="collapse">\n' +
                                    '                <hr>\n' +
                                    '                <form action="/replytocomment_add" method="post" class="replyform form-inline">\n' +
                                    '                    {{csrf_field()}}\n' +
                                    '                    <input type="hidden" name="comment_id" value="'+data.id+'">\n' +
                                    '                    <input type="hidden" name="article_id" value="'+data['article']['id']+'">\n' +
                                    '                    <textarea class="form-control" style="width:78%;" placeholder="{{__("discussion.replytothiscomment")}}" name="content" rows="1"></textarea>\n' +
                                    '                    <button type="submit" class="btn btn-default">{{__('discussion.submitreply')}}</button>\n' +
                                    '                </form>\n' +
                                    '                <hr>\n'+
                                    '            </div>\n' +
                                    '        </div>\n' +
                                    '    </div>\n' +
                                    '</li>\n';
                                $('#commentCount').html(parseInt($('#commentCount').html())+1);
                                $('#saveComment > textarea').val('');
                                $('#comments').prepend(commentContents);

                            } else {

                            }
                        },
                        cache: false,
                        contentType: false,
                        processData: false,
                    });

                    return false;
                    // or alert($(this).hash();
                });

                $('#comments').on('click', '.editComment', function(e){
                    e.preventDefault();
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        success:function(data){
                            if(data){
                                $('#id').val(data.id);
                                $('#comment_body').val(data.reply);
                                $('#editCommentModal').modal('show');
                            }else{
                                alert("You don't have permission to edit this comment!");
                            }
                        },
                        error: function (data) {
                            alert('Looking something went wrong!');
                        }
                    });
                    return false;
                });

                $('#editCommentForm').on('submit', function(e){
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/forum/update_comment") }}',
                        type: 'post',
                        data: formData,
                        success: function (data) {
                            if (data) {
                                $('#comment'+data.id+'').html(data.reply);
                                $('#editCommentModal').modal('hide');

                            } else {

                            }
                        },
                        cache: false,
                        contentType: false,
                        processData: false,
                    });

                    return false;
                    // or alert($(this).hash();
                });
                $('#comments').on('click', '.deleteComment', function(e){
                    e.preventDefault();
                    var url=$(this).attr('href');
                    if (confirm("Are you sure?")) {
                        $.ajax({
                            url: url,
                            type: 'get',
                            success: function (data) {
                                if (data) {
                                    $('#comment' + data.id + '').parent().parent().parent().hide();
                                } else {
                                    alert("You don't have permission to delete this comment!");
                                }
                                $('#commentCount').html(parseInt($('#commentCount').html())-1);
                            },
                            error: function (data) {
                                alert('Looking something went wrong!');
                            }
                        });
                    }
                    return false;
                });
                //like article
                $('#comments').on('click', '.likeComment', function(e){
                    e.preventDefault();
                    var like=$(this);
                    var url=like.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            if (data.like=='liked') {
                                like.siblings('a').find('span').html(parseInt(like.siblings('a').find('span').html())+1);
                                like.css({'color': '#0b97c4', 'font-size': '18px'});
                            } else {
                                like.siblings('a').find('span').html(parseInt(like.siblings('a').find('span').html())-1);
                                like.css({'color': '#32383e', 'font-size': '16px'});
                            }
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });

                //comment to reply
                $('#comments').on('submit', '.replyform', function(e){
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/replytocomment_add") }}',
                        type: 'post',
                        data: formData,
                        success: function (Rdata) {
                            let data=Rdata.comment;
                            if (data){
                                replyContents="";
                                replyContents+=  '<ul class="media-list">\n' +
                                    '                    <li class="media media-replied">\n' +
                                    '                        <a class="pull-left profile_image" href="/users/profile/ajax/' + data.user_id +'}}">\n';
                                if(data.user.image){
                                    replyContents+='<img class="media-object img-circle" src="'+ data.user.image +'" alt="profile">';

                                }else{
                                    if(data.user.gender==1){
                                        replyContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    }else{
                                        replyContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==data.user_id){
                                                hiddenClass="";
                                        }
                                replyContents+='  </a>\n' +
                                    '                        <div class="media-body">\n' +
                                    '                            <div class="well well-sm" style="background-color: white">\n' +
                                    '            <table width="100%">\n' +
                                    '               <tr>\n' +
                                    '                   <td>\n' +
                                    '                       <h5 class="media-heading text-uppercase reviews">'+data["user"]["name"]+ ' ' + data["user"]["last_name"]+'</h5>\n' +
                                    '                   </td>\n' +
                                    '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                    '                       <a class="fa fa-edit editReply '+ hiddenClass +'" href="/edit/your/reply/'+ data.id +'"></a>\n' +
                                    '                       <a class="fa fa-fw fa-trash-o deleteReply '+ hiddenClass +'" href="/delete/your/reply/' + data.id+'"></a>\n' +
                                    '                   </td>\n' +
                                    '               </tr>\n' +
                                    '            </table>'+
                                    '                                <ul class="media-date text-uppercase reviews list-inline">\n' +
                                    '                                    <li style="color: #0b97c4; font-size: 14px;">'+data.reply_date+'</li>\n' +
                                    '                                </ul>\n' +
                                    '                                <p class="media-comment" id="reply'+data.id+'">\n' +
                                    data.content +
                                    '                                </p>\n' +
                                    '                                <a class="fa fa-thumbs-o-up likeReply" href="forum/article/likereply/' + data.id+'" id=""\n' ;
                                //verify if the current user liked the reply or not
                                var liked = $.grep(data.likes, function(item) {
                                    return item.user_id == {{Auth::user()->id}};
                                });
                                if(liked.length){
                                    replyContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                }else{
                                    replyContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                }

                                replyContents+= ' {{__("discussion.like")}} | <a class="replyLikes" href="/forum/reply/likes/'+data.id+'"><span>' + data.likes.length + '</span></a>'+
                                    '                                \n' +
                                    '                            </div>\n' +
                                    '                        </div>\n' +
                                    '                    </li>\n' +
                                    '                </ul>\n';
                                
                                $('.replyform').trigger("reset");
                                $('#demo'+data.comment_id+' hr:first-child').after(replyContents);
                                $('#replyCount').html(parseInt($('#replyCount').html())+1);
                                $('#demo'+data.comment_id+'').prev().find(".rCount").html(parseInt($('#demo'+data.comment_id+'').prev().find(".rCount").html())+1);

                            } else {

                            }
                        },
                        cache: false,
                        contentType: false,
                        processData: false,
                    });

                    return false;
                    // or alert($(this).hash();
                });

                //delete reply
                $('#comments').on('click', '.deleteReply', function(e){
                    e.preventDefault();
                    var reply=$(this);
                    var url=$(this).attr('href');
                    if (confirm("Are you sure?")) {
                        $.ajax({
                            url: url,
                            type: 'get',
                            success: function (data) {
                                if (data) {
                                    reply.parent().parent().parent().parent().parent().parent().parent().hide();
                                } else {
                                    alert("You don't have permission to delete this reply!");
                                }
                                $('#replyCount').html(parseInt($('#replyCount').html())-1);
                                $('#demo'+data.comment_id+'').prev().find(".rCount").html(parseInt($('#demo'+data.comment_id+'').prev().find(".rCount").html())-1);
                            },
                            error: function (data) {
                                alert('Looking something went wrong!');
                            }
                        });
                    }
                    return false;
                });

                //edit reply
                $('#comments').on('click', '.editReply', function(e){
                    e.preventDefault();
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        success:function(data){
                            if(data){
                                $('#replyId').val(data.id);
                                $('#reply_body').val(data.content);
                                $('#editReplyModal').modal('show');
                            }else{
                                alert("You don't have permission to edit this reply!");
                            }
                        },
                        error: function (data) {
                            alert('Looking something went wrong!');
                        }
                    });
                    return false;
                });

                //update reply
                $('#editReplyForm').on('submit', function(e){
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        url: '{{ url("/forum/update_reply") }}',
                        type: 'post',
                        data: formData,
                        success: function (data) {
                            if (data) {
                                $('#reply'+data.id+'').html(data.content);
                                $('#editReplyModal').modal('hide');

                            } else {

                            }
                        },
                        cache: false,
                        contentType: false,
                        processData: false,
                    });

                    return false;
                    // or alert($(this).hash();
                });

                //like reply
                $('#comments').on('click', '.likeReply', function(e){
                    e.preventDefault();
                    var like=$(this);
                    var url=like.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            if (data.like=='liked') {
                                like.css({'color': '#0b97c4', 'font-size': '18px'});
                                like.siblings("a").find('span').html(data.count);
                            } else {
                                like.css({'color': '#32383e', 'font-size': '16px'});
                                like.siblings("a").find('span').html(data.count);
                            }
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });

                //show article
                $('#articles').on('click', '.article', function(e){
                    e.preventDefault();
                    var url=$(this).attr('href');
                    $.ajax({
                        url:url,
                        type:'get',
                        beforeSend:function(){
                          $('#loading').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                        },
                        success:function(data){
                            $('#loading').modal('hide');
                            var lang = '<?php echo $locale ?>';
                            var table = $('#articles');

                            //article content
                            $('#article_title').html(data['articles']['title']);
                            $('#profile_image').attr("href", "/users/profile/ajax/"+data['articles']['user_id']);
                            if(data['articles']['user']['image']){
                                $('#profile_link').attr('src', data['articles']['user']['image']);
                            }else{
                                if(data['articles']['user']['gender']==1){
                                    $('#profile_link').attr('src', 'profile_pic/profile_simple.png');
                                }else{
                                    $('#profile_link').attr('src', 'profile_pic/profile_simple_gril.png');
                                }
                            }
                            $('#user_name').html(data['articles']['user']['name'] + ' ' + data['articles']['user']['last_name']);
                            $('#created_at').html(data['articles']['created_at']);
                            $('#editArticle').attr('href', '/forum/editarticle/'+data['articles']['id']);

                            if(data['articles']['user']['id'] == '{{Auth::user()->id}}' || '{{Auth::user()->user_type}}'==1){

                            }else{
                                $('#editArticle').addClass('hidden');
                            }

                            $('#article_body').empty();
                            $('#article_body').html(data['articles']['body']);
                            if(data['articles']['attachment'].length>1){
                                $('#article_attachment').html('<a href="'+ data['articles']['attachment'] +'" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang("discussion.attached_file")</a>');
                            }else{
                                $('#article_attachment').html('');
                            }
                            $('#article_id').parent().parent().parent().parent().show();

                            //article comment, likes, replies count
                            $('#like').attr('href', '/forum/article/like/'+ data['articles']['id']);
                            $('#likesCount').html(data['articles']['likes'].length);
                            $('.likes').attr('href', '/forum/article/likes/'+data['articles']['id']);
                            
                            //verify if the current user liked the article or not
                                        var liked = $.grep(data['articles']['likes'], function (item) {
                                            return item.user_id == {{Auth::user()->id}};
                                        });
                                        if (liked.length) {
                                            $('#like_color').css({'color': '#0b97c4', 'font-size': '23px'});
                                        } else {
                                            $('#like_color').css({'color': '#32383e', 'font-size': '20px'});
                                        }

                            $('#commentCount').html(data['articles']['comments'].length);

                            $('#replyCount').html(data['articles']['replies'].length);

                            //comment and replies
                            $('#article_id').attr('value', data['articles']['id']);
                            var commentContents='';
                            $.each(data.articles.comments, function (index , value) {
                                commentContents+= '<li class="media countable">' +
                                    '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                if(value.user.image){
                                    commentContents+='<img class="media-object img-circle" src="'+ value.user.image +'" alt="profile">';

                                }else{
                                    if(value.user.gender==1){
                                        commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    }else{
                                        commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                var hiddenClass="hidden";
                                if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==value.user_id){
                                            hiddenClass="";
                                        }
                                        
                                        

                                commentContents+='    </a>\n' +
                                    '    <div class="media-body">\n' +
                                    '        <div class="well well-sm">\n' +
                                    '            <table width="100%">\n' +
                                    '               <tr>\n' +
                                    '                   <td>\n' +
                                    '                       <h5 class="media-heading text-uppercase reviews">'+value["user"]["name"]+ ' ' + value["user"]["last_name"]+'</h5>\n' +
                                    '                   </td>\n' +
                                    '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                    '                       <a class="fa fa-edit editComment '+ hiddenClass +'" href="forum/edit_comment/'+ value.id +'"></a>\n' +
                                    '                       <a class="fa fa-fw fa-trash-o deleteComment '+ hiddenClass +'" href="/forum/delete_usercomment/' + value.id+'"></a>\n' +
                                    '                   </td>\n' +
                                    '               </tr>\n' +
                                    '            </table>'+
                                    '            <ul class="media-date text-uppercase reviews list-inline">\n' +
                                    '                <li style="color: #0b97c4; font-size: 14px;">'+ value.created_at +'</li>\n' +
                                    '            </ul>\n' +
                                    '            <p class="media-comment" id="comment'+value.id+'">\n' +
                                    value.reply +
                                    '            </p>\n' +
                                    '            <table width="100%">\n' +
                                    '                <tr>\n' +
                                    '                    <td style="@if($locale=="en") text-align: left; @else text-align: right; @endif">\n' +
                                    '                        <a class="fa fa-thumbs-o-up likeComment" href="forum/article/likecomment/' + value.id+ '" \n';

                                //verify if the current user liked the comment of not
                                var liked = $.grep(value.likes, function(item) {
                                    return item.user_id == {{Auth::user()->id}};
                                });
                                if(liked.length){
                                    commentContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                }else{
                                    commentContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                }

                                commentContents+= ' {{__("discussion.like")}}| <a class="commentLikes" href="/forum/comment/likes/'+value.id+'"><span id="commentlikesCount">' + value.likes.length + '</span></a>\n' +
                                    '                        \n' +
                                    '                    </td>\n' +
                                    '                    <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif">\n' +
                                    '                        <a class="fa fa-reply" data-toggle="collapse" href="#demo'+value.id+'" id="reply"> {{__("discussion.reply")}} | </a> <span class="rCount">' + value.replies.length + '</span>\n' +
                                    '                    </td>\n' +
                                    '                </tr>\n' +
                                    '            </table>\n' +
                                    '            <div id="demo'+value.id+'" class="collapse">\n' +
                                    '                <hr>\n' +
                                    '                <form action="/replytocomment_add" method="post" class="replyform  form-inline">\n' +
                                    '                    {{csrf_field()}}\n' +
                                    '                    <input type="hidden" name="comment_id" value="'+value.id+'">\n' +
                                    '                    <input type="hidden" name="article_id" value="'+data['articles']['id']+'">\n' +
                                    '                    <textarea class="form-control" style="width:78%;" placeholder="{{__("discussion.replytothiscomment")}}" name="content" rows="1"></textarea>\n' +
                                    '                    <button type="submit" class="btn btn-default">{{__('discussion.submitreply')}}</button>\n' +
                                    '                </form>\n' +
                                    '                <hr>\n';

                                $.each(value.replies, function (index, reply) {
                                    commentContents+=  '<ul class="media-list">\n' +
                                        '                    <li class="media media-replied">\n' +
                                        '                        <a class="pull-left profile_image" href="/users/profile/ajax/' + reply.user_id +'}}">\n';
                                    if(reply.user.image){
                                        commentContents+='<img class="media-object img-circle" src="'+ reply.user.image +'" alt="profile">';

                                    }else{
                                        if(reply.user.gender==1){
                                            commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                        }else{
                                            commentContents+='<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                        }
                                    }
                                    var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==reply.user_id){
                                                hiddenClass="";
                                        }
                                    commentContents+='  </a>\n' +
                                        '                        <div class="media-body">\n' +
                                        '                            <div class="well well-sm" style="background-color: white">\n' +
                                        '            <table width="100%">\n' +
                                        '               <tr>\n' +
                                        '                   <td>\n' +
                                        '                       <h5 class="media-heading text-uppercase reviews">'+reply["user"]["name"]+ ' ' + reply["user"]["last_name"]+'</h5>\n' +
                                        '                   </td>\n' +
                                        '                   <td style="text-align: @if($locale=="en") right @else left @endif;">\n' +
                                        '                       <a class="fa fa-edit editReply '+ hiddenClass +'" href="/edit/your/reply/'+ reply.id +'"></a>\n' +
                                        '                       <a class="fa fa-fw fa-trash-o deleteReply '+ hiddenClass +'" href="/delete/your/reply/' + reply.id+'"></a>\n' +
                                        '                   </td>\n' +
                                        '               </tr>\n' +
                                        '            </table>'+
                                        '                                <ul class="media-date text-uppercase reviews list-inline">\n' +
                                        '                                    <li style="color: #0b97c4; font-size: 14px;">'+reply.reply_date+'</li>\n' +
                                        '                                </ul>\n' +
                                        '                                <p class="media-comment" id="reply'+reply.id+'">\n' +
                                        reply.content +
                                        '                                </p>\n' +
                                        '                                <a class="fa fa-thumbs-o-up likeReply" href="forum/article/likereply/' + reply.id+'"\n' ;
                                    //verify if the current user liked the reply or not
                                    var liked = $.grep(reply.likes, function(item) {
                                        return item.user_id == {{Auth::user()->id}};
                                    });
                                    if(liked.length){
                                        commentContents+='style="color: #0b97c4; font-size: 18px;"> </a>';
                                    }else{
                                        commentContents+='style="color: #32383e; font-size: 16px;"> </a>';
                                    }

                                    commentContents+= ' {{__("discussion.like")}} | <a class="replyLikes" href="/forum/reply/likes/'+reply.id+'"><span>' + reply.likes.length + '</span></a>'+
                                        '                                \n' +
                                        '                            </div>\n' +
                                        '                        </div>\n' +
                                        '                    </li>\n' +
                                        '                </ul>\n';
                                });

                                commentContents+='            </div>\n' +
                                    '        </div>\n' +
                                    '    </div>\n' +
                                    '</li>\n';
                            });
                            if(data.articles.comments.length>0) {
                                $('#comments').html(commentContents);
                            }else{
                                $('#comments').html('');
                            }
                            var list = $("#comments li.countable");
                                  var numToShow = 5;
                                  var button = $("#next");
                                  var numInList = list.length;
                                  list.hide();
                                  button.hide();
                                  if (numInList > numToShow) {
                                    button.show();
                                  }
                                  list.slice(0, numToShow).show();
                        },
                        error: function (data) {
                            $('#loading').modal('hide');
                            alert('Looking something went wrong!');
                        }
                    });
                    return false;
                });
                
                //like reply
                $('#read_more').click(function(e){
                    e.preventDefault();
                    var like=$(this);
                    var url=like.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        beforeSend:function(){
                          $('#read_more').html('{{__("discussion.loading")}}');
                        },
                        success: function (data) {
                          
                           var table = $('#articles');
                                var cat_id="";
                                var art_id="";
                                $.each(data, function (index, value) {
                                    var name="";
                                    var last_name="";
                                    if(value["user"]) {
                                        name = value["user"]["name"];
                                        last_name = value["user"]["last_name"];
                                    }
                                    var hiddenClass="hidden";
                                        if({{Auth::user()->user_type}}==1 || {{Auth::user()->id}}==value.user_id){
                                            hiddenClass="";
                                        }
                                    table.append(
                                        '<tr>' +
                                        '<td>' +
                                        '<a class="article" href="forum/article/'+value.id+'">' +
                                        '<i class="fa fa-fw fa-file-text-o" aria-hidden="true"></i>' + value.title +
                                        '</a>' +
                                        '</td>' +
                                        '<td style="color:gray; font-size:12px;">'+ value.created_at +'</td>' +
                                        '<td>' +
                                        '<a class="profile_image" href="/users/profile/ajax/' + value.user_id + '" style="color:#444; font-size: 12px;" target="_blank">' +
                                        '<i class="fa fa-fw fa-user-o" aria-hidden="true"></i>' + name + ' ' + last_name +
                                        '</a>' +
                                        '</td>' +
                                        '<td class="text-center '+hiddenClass+'">' +
                                        '<a class="del" href="/deleteforum/' + value.id + '">' +
                                        '<i class="fa fa-fw fa-trash-o" title="Delete this record"></i>' +
                                        '</a></td>' +
                                        '</tr>'
                                    );
                                    
                                        cat_id=value.category_id;
                                        art_id=value.id;
                                });
                                $('#read_more').attr('href', '/forum/readMore/'+cat_id + '/'+ art_id);
                                $('#read_more').html('{{__('discussion.more_discussions')}}');
                        },
                        error: function (data) {
                            $('#read_more').html('{{__('discussion.more_discussions')}}');
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });
                //article likes list
                $('.likes').click(function(e){
                    e.preventDefault();
                    var likes=$(this);
                    var url=likes.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            commentContents="";
                            $.each(data, function (index, value) {
                                commentContents += '<ul class="media-list">\n' +
                                    '<table>'+
                                    '<tr>'+
                                    '<td>'+
                                    '<li class="media countable">' +
                                    '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                if (value.user.image) {
                                    commentContents += '<img class="media-object img-circle" src="' + value.user.image + '" alt="profile">';

                                } else {
                                    if (value.user.gender == 1) {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    } else {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                commentContents += '</a></li></td><td>'+
                                    '<table width="100%">\n' +
                                '               <tr>\n' +
                                '                   <td>\n' +
                                '                       <h5 class="media-heading text-uppercase reviews">'+value["user"]["name"]+ ' ' + value["user"]["last_name"]+'</h5>\n' +
                                '                   </td>\n' +
                                '               </tr>\n' +
                                '            <tr class="media-date text-uppercase reviews list-inline" >\n' +
                                '                <td><li style="color: #0b97c4; font-size: 14px;">'+ value.user.user_type.en_title +'</li></td>\n' +
                                '            </tr>' +
                                '            </table></td></tr></table>'+
                                '</ul>\n';
                            });
                            $('#likes').html(commentContents);
                            $('#likeModal').modal('show');
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });
                
                //comment likes list
                $('#comments').on('click', '.commentLikes', function(e){
                    e.preventDefault();
                    var likes=$(this);
                    var url=likes.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            commentContents="";
                            $.each(data, function (index, value) {
                                commentContents += '<ul class="media-list">\n' +
                                    '<table>'+
                                    '<tr>'+
                                    '<td>'+
                                    '<li class="media countable">' +
                                    '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                if (value.user.image) {
                                    commentContents += '<img class="media-object img-circle" src="' + value.user.image + '" alt="profile">';

                                } else {
                                    if (value.user.gender == 1) {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    } else {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                commentContents += '</a></li></td><td>'+
                                    '<table width="100%">\n' +
                                '               <tr>\n' +
                                '                   <td>\n' +
                                '                       <h5 class="media-heading text-uppercase reviews">'+value["user"]["name"]+ ' ' + value["user"]["last_name"]+'</h5>\n' +
                                '                   </td>\n' +
                                '               </tr>\n' +
                                '            <tr class="media-date text-uppercase reviews list-inline" >\n' +
                                '                <td><li style="color: #0b97c4; font-size: 14px;">'+ value.user.user_type.en_title +'</li></td>\n' +
                                '            </tr>' +
                                '            </table></td></tr></table>'+
                                '</ul>\n';
                            });
                            $('#likes').html(commentContents);
                            $('#likeModal').modal('show');
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });
                
                //reply likes list
                $('#comments').on('click', '.replyLikes', function(e){
                    e.preventDefault();
                    var likes=$(this);
                    var url=likes.attr('href');
                    $.ajax({
                        url: url,
                        type: 'get',
                        success: function (data) {
                            commentContents="";
                            $.each(data, function (index, value) {
                                commentContents += '<ul class="media-list">\n' +
                                    '<table>'+
                                    '<tr>'+
                                    '<td>'+
                                    '<li class="media countable">' +
                                    '    <a class="pull-left profile_image" href="/users/profile/ajax/' + value.user_id + '">';
                                if (value.user.image) {
                                    commentContents += '<img class="media-object img-circle" src="' + value.user.image + '" alt="profile">';

                                } else {
                                    if (value.user.gender == 1) {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple.png" alt="profile">';
                                    } else {
                                        commentContents += '<img class="media-object img-circle" src="profile_pic/profile_simple_gril.png" alt="profile">';
                                    }
                                }
                                commentContents += '</a></li></td><td>'+
                                    '<table width="100%">\n' +
                                '               <tr>\n' +
                                '                   <td>\n' +
                                '                       <h5 class="media-heading text-uppercase reviews">'+value["user"]["name"]+ ' ' + value["user"]["last_name"]+'</h5>\n' +
                                '                   </td>\n' +
                                '               </tr>\n' +
                                '            <tr class="media-date text-uppercase reviews list-inline" >\n' +
                                '                <td><li style="color: #0b97c4; font-size: 14px;">'+ value.user.user_type.en_title +'</li></td>\n' +
                                '            </tr>' +
                                '            </table></td></tr></table>'+
                                '</ul>\n';
                            });
                            $('#likes').html(commentContents);
                            $('#likeModal').modal('show');
                        },
                        error: function (data) {
                            alert('Failed to load!');
                        }
                    });

                    return false;
                    // or alert($(this).hash();
                });

            });
    </script>
    <div class="container-fluid" style="padding: 0px;">
        <style>
            #myList li{ display:none;
        }
        #articleContents {
            word-wrap: break-word
        }
        #loadMore {
            color:green;
            cursor:pointer;
        }
        #loadMore:hover {
            color:black;
        }
        #showLess {
            color:red;
            cursor:pointer;
        }
        #showLess:hover {
            color:black;
        }
        </style>
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10" style="padding: 0px;">
                <div id="loading" class="modal fade" style="text-align: center;" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body" style="padding: 2em;">
                                <style>
                                    .loader {
                                        border: 16px solid #f3f3f3;
                                        border-radius: 50%;
                                        border-top: 16px solid #3498db;
                                        width: 120px;
                                        height: 120px;
                                        -webkit-animation: spin 2s linear infinite; /* Safari */
                                        animation: spin 2s linear infinite;
                                    }

                                    /* Safari */
                                    @-webkit-keyframes spin {
                                        0% { -webkit-transform: rotate(0deg); }
                                        100% { -webkit-transform: rotate(360deg); }
                                    }

                                    @keyframes spin {
                                        0% { transform: rotate(0deg); }
                                        100% { transform: rotate(360deg); }
                                    }
                                </style>
                                <div class="loader" style="margin: 0 auto; text-align: left"></div>
                                <div style="margin: 0 auto; margin-top: 1em;">{{__("discussion.loading")}}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wrapper">
                    <div class="box">
                        <div class="row row-offcanvas row-offcanvas-left" style="background-color: white;">
                            <div class="column col-sm-3 col-xs-1 sidebar-offcanvas" style="background-color: #205493; border-bottom:  0.2em double white;">
                                <div style="margin-top: 0.3em; margin-bottom: 0.3em; @if($locale=="en") margin-left:1.5em; border-left: 0.15em solid #c3143c; padding-left:0.3em; @else margin-right:1.5em; border-right:  0.15em solid #c3143c; padding-right:0.3em; @endif">
                                    <span style="color: snow; font-size: 0.8em;">{{ __('home.promote') }}</span> <br>
                                    <span style="color: white; font-size: 1em;">{{__('home.musharikat')}}</span>
                                </div>
                            </div>
                            <!-- main right col -->
                            <div class="column col-sm-9 col-xs-11" style="padding-left: 50px; padding-right: 50px; font-size: 1.2em;">
                                <ul class="nav navbar-nav">

                                    <li>
                                        <a href="#postModal" role="button" data-toggle="modal" style="margin-top: 0.3em; color: black;"><i class="glyphicon glyphicon-plus" style="font-size: 1.3em; font-weight: bolder; "></i> @lang('discussion.Add_New_Article')</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="row row-offcanvas row-offcanvas-left">
                            <!-- sidebar -->
                            <div class="column col-sm-3 col-xs-1 sidebar-offcanvas" id="sidebar">

                                <ul class="nav">
                                    <li><a href="#" data-toggle="offcanvas" class="visible-xs text-center"><i class="fa fa-chevron-right"></i></a></li>
                                </ul>

                                <ul class="nav hidden-xs" id="lg-menu">
                                    @foreach($categories as $category)
                                        @php
                                            $found = DB::table('user_coalitions')->where('user_id', Auth::user()->id)
                                            ->where('coalition_id', $category->coalition_id)
                                            ->count();

                                            /* General Category */
                                            if($category->id == 1 or $category->id == 17)
                                            {
                                              $found = 1;
                                            }
                                        @endphp
                                        @if($found == 1)
                                            <li class="active">
                                                <a class="category" href="forum/category/{{$category->id}}"><i class="{{$category->icon}}"></i>
                                                    @if($locale == 'en')
                                                        {{ $category->en_title }}
                                                    @elseif($locale == 'da')
                                                        {{ $category->da_title }}
                                                    @else
                                                        {{ $category->ps_title }}
                                                    @endif
                                                </a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>

                                <!-- tiny only nav-->
                                <ul class="nav visible-xs" id="xs-menu">
                                    @foreach($categories as $category)
                                        @php
                                            $found = DB::table('user_coalitions')->where('user_id', Auth::user()->id)
                                            ->where('coalition_id', $category->coalition_id)
                                            ->count();

                                            /* General Category */
                                            if($category->id == 1 or $category->id == 17)
                                            {
                                              $found = 1;
                                            }
                                        @endphp
                                        @if($found == 1)
                                            <li class="active">
                                                <a class="category" href="forum/category/{{$category->id}}"><i class="{{$category->icon}}"></i></a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>

                            </div>
                            <!-- /sidebar -->

                            <!-- main right col -->
                            <div class="column col-sm-9 col-xs-11" id="main">
                                <!-- /top nav -->
                                <style>
                                    .avatar img {
                                        width: 60px;
                                        height: 60px;
                                        max-width: 60px;
                                        max-height: 60px;
                                        -webkit-border-radius: 50%;
                                        -moz-border-radius: 50%;
                                        border-radius: 50%;
                                        border: 5px solid rgba(255,255,255,0.5);
                                    }
                                </style>
                                <div class="padding" >
                                    <div class="full col-sm-9" style="padding: 0px;">

                                        <!-- content -->
                                        <div class="row">

                                            <!-- main col left -->
                                            <div class="col-sm-7">
                                                <div id="editCommentModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
                                                                <span>
                                                                        Edit Comment
                                                                    </span>
                                                            </div>
                                                            <div class="modal-body" style="padding: 2em;">
                                                                <form class="form" id="editCommentForm" action="{{ url('forum/update_comment') }}" method="post">
                                                                    {{ csrf_field() }}
                                                                    <input type="hidden" name="id" id="id" value="">
                                                                    <div class="form-group">
                                                                        <label for="reply">Commment</label>
                                                                        <textarea name="reply" id="comment_body" class="form-control" rows="4" cols="40"></textarea>

                                                                        @if($errors->has('reply'))
                                                                            <div class="error">
                                                                                {{ $errors->first('reply') }}
                                                                            </div>
                                                                        @endif
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <button type="submit" name="button" class="btn btn-primary">
                                                                            <i class="fa fa-fw fa-floppy-o" aria-hidden="true"></i>
                                                                            Update Changes
                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="editReplyModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
                                                                <span>
                                                                   Edit Reply
                                                                </span>
                                                            </div>
                                                            <div class="modal-body" style="padding: 2em;">
                                                                <form class="form" id="editReplyForm" action="{{ url('forum/update_reply') }}" method="post">
                                                                    {{ csrf_field() }}
                                                                    <input type="hidden" name="id" id="replyId" value="">
                                                                    <div class="form-group">
                                                                        <label for="reply">{{__('discussion.submitreply')}}</label>
                                                                        <textarea name="reply" id="reply_body" class="form-control" rows="4" cols="40"></textarea>

                                                                        @if($errors->has('reply'))
                                                                            <div class="error">
                                                                                {{ $errors->first('reply') }}
                                                                            </div>
                                                                        @endif
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <button type="submit" name="button" class="btn btn-primary">
                                                                            <i class="fa fa-fw fa-floppy-o" aria-hidden="true"></i>
                                                                            Update Changes
                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="likeModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
                                                                <span>
                                                                   {{__('discussion.like')}}
                                                                </span>
                                                            </div>
                                                            <div class="modal-body" style="padding: 2em;" id="likes">

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                @php
                                                    $article = \App\Forum_articles::with('user', 'comments', 'likes')->where('category_id', 1)->orderBy('id', 'DESC')->first();
                                                @endphp
                                                <div class="panel panel-default" id="articleContents">
                                                    <div class="panel-heading"><h4 id="article_title">{{$article->title}}</h4></div>
                                                    <div class="panel-body">
                                                        <div class="panel-thumbnail" >
                                                            <table width="100%">
                                                                <tr>
                                                                    <td width="60em">
                                                                        <a id="profile_image" class="profile_image" href=" {{ url('/users/profile/ajax/' . $article->user_id )}}">
                                                                            <div class="avatar">
                                                                                <img id="profile_link" width="50em" src="@if($article->user->image){{$article->user->image}}@else @if($article->user->gender==1) profile_pic/profile_simple.png @else profile_pic/profile_simple_gril.png @endif @endif">
                                                                            </div>
                                                                        </a>
                                                                    </td>
                                                                    <td>
                                                                        <table>
                                                                            <tr style="color: #000066">
                                                                                <td id="user_name">{{$article->user->name. ' '. $article->user->last_name}}</td>
                                                                            </tr>
                                                                            <tr style="color: #00aeef; font-size: 13px;">
                                                                                <td id="created_at">{{$article->created_at}}</td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                    <td width="10%">
                                                                        <a class="fa fa-edit @if($article->user_id==Auth::user()->id or Auth::user()->user_type==1) @else hidden @endif" href=" {{ url('/forum/editarticle/' . $article->id )}}" id="editArticle"> Edit</a>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                        <style>
                                                            img{
                                                                max-width: 100%;
                                                            }
                                                            #articleContents a{
                                                                text-decoration: none;
                                                            }
                                                            #articleContents a:hover {
                                                                transform: scale(1.13);
                                                            }
                                                          
                                                        </style>
                                                        <div id="article_body"">{!! $article->body !!}</div>
                                                        <div id="article_attachment">
                                                            @if(strlen($article->attachment) > 1)
                                                                <a href="{{$article->attachment}}" class="form-control fa fa-file-text-o" style="font-size:16px" target="_blank">@lang('discussion.attached_file')</a>
                                                            @endif
                                                        </div>
                                                        <hr>
                                                        <div style="margin: 0 auto;">
                                                            <table width="100%" style="font-size: 12px;">
                                                                <tr>
                                                                    <td style="white-space: nowrap; @if($locale=="en") text-align: left; @else text-align: right; @endif"><a style="padding: 0px; margin: 0px;" id="like" href="{{ url('/forum/article/like/' . $article->id)}}" class="btn btn-sm">
                                                                            <i id="like_color" style="font-size: 22px; margin: 5px; @if(\App\ArticleReaction::where('article_id', $article->id)->where('user_id', Auth::user()->id)->get()->count() > 0) color: #0b97c4; @else color: #32383e; @endif" class="fa fa-thumbs-o-up"></i>
                                                                        </a>{{__('discussion.like')}}| <a class="likes" href="/forum/article/likes/{{$article->id}}"><span id="likesCount">{{count($article['likes'])}}</span></a>
                                                                    </td>
                                                                    <td style="text-align: center; white-space: nowrap;"><a href="#comment" data-toggle="collapse" class="btn btn-xs">
                                                                            <i class="fa fa-commenting-o" aria-hidden="true" style="font-size: 20px; color: #0b97c4"></i>
                                                                        </a>{{__("discussion.comment")}} | <span id="commentCount">{{count($article['comments'])}}</span>
                                                                    </td>
                                                                    <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif white-space: nowrap;"><i class="fa fa-reply" style="font-size: 20px; color: #0b97c4"></i>{{__("discussion.reply")}}|<span id="replyCount">{{\App\ReplyToComment::where('article_id',$article->id)->count()}}</span></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <div class="panel-footer">
                                                    </div>
                                                
                                                    <div class="panel" style="@if($locale=="en") margin-right: 0.5em; margin-left: 0.5em; @else margin-left: 0.5em; margin-right: 1em; @endif" id="comment">
                                                        <a class="pull-left profile_image" style="@if($locale=="en") margin-right: 0.6em; @else margin-left: 0.6em; @endif" href=" {{ url('/users/profile/ajax/' . Auth::user()->id )}}">
                                                                <img class="media-object img-circle" src="@if(Auth::user()->image){{Auth::user()->image}}@else @if(Auth::user()->gender==1) profile_pic/profile_simple.png @else profile_pic/profile_simple_gril.png @endif @endif" alt="profile">
                                                        </a>
                                                        <div class="panel-body" style="margin-right: 0.5em; margin-left: 0.5em;">
                                                            <form class="form-inline" role="form" id="saveComment" action="{{ url('/forum/save_reply') }}" method="post">
                                                                {{ csrf_field() }}
                                                                <input type="hidden" name="article_id" id="article_id" value="{{$article->id}}">
                                                                <textarea name="reply" class="form-control reply-editor commmentTextarea" placeholder="{{__('discussion.addnewcommenttothispost')}}" rows="1" style="width:78%;">{{ old('reply') }}</textarea>
                                                                <button type="submit" name="button" class="btn btn-default">
                                                                    {{__('discussion.submitreply')}}
                                                                </button>
                                                            </form>
                                                
                                                        </div>
                                                    
                                                    </div>

                                                    <div class="tab-content" style="padding: 0.5em;">
                                                        <div class="tab-pane active">
                                                            <ul class="media-list" id="comments">
                                                                @foreach($article['comments'] as $comment)
                                                                    @php $replyToComment=\App\ReplyToComment::with('likes')->where('comment_id', $comment->id)->get(); @endphp
                                                                    <li class="media countable">
                                                                        <a class="pull-left profile_image" href=" {{ url('/users/profile/ajax/' . $comment->user_id )}}">
                                                                            <img class="media-object img-circle" src="@if($comment->user->image){{$comment->user->image}}@else @if($comment->user->gender==1) profile_pic/profile_simple.png @else profile_pic/profile_simple_gril.png @endif @endif" alt="profile">
                                                                        </a>
                                                                        <div class="media-body">
                                                                            <div class="well well-sm">
                                                                                <table width="100%">
                                                                                    <tr>
                                                                                        <td>
                                                                                            <h5 class="media-heading text-uppercase reviews">{{$comment['user']['name']. ' ', $comment['user']['last_name']}}</h5>
                                                                                        </td>
                                                                                        <td style="text-align: @if($locale=='en') right @else left @endif;">
                                                                                            <a class="fa fa-edit editComment @if($comment->user_id != Auth::user()->id and Auth::user()->user_type!=1) hidden @endif" href=" {{ url('forum/edit_comment/' . $comment->id )}}"></a>
                                                                                            <a class="fa fa-fw fa-trash-o deleteComment @if($comment->user_id != Auth::user()->id and Auth::user()->user_type!=1) hidden @endif" href=" {{ url('/forum/delete_usercomment/' . $comment->id )}}"></a>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                                <ul class="media-date text-uppercase reviews list-inline">
                                                                                    <p style="color: #0b97c4; font-size: 14px;">{{$comment->created_at}}</p>
                                                                                </ul>
                                                                                <p class="media-comment" id="comment{{$comment->id}}">
                                                                                    {!! $comment->reply !!}
                                                                                </p>
                                                                                <table width="100%">
                                                                                    <tr>
                                                                                        <td style="@if($locale=="en") text-align: left; @else text-align: right; @endif">
                                                                                            <a class="fa fa-thumbs-o-up likeComment" href="{{ url('/forum/article/likecomment/' . $comment->id)}}"
                                                                                               style="@if(\App\CommentReaction::where('article_id', $comment->id)->where('user_id', Auth::user()->id)->count() > 0) color: #0b97c4; font-size: 18px; @else color: #32383e; @endif">
                                                                                            </a>
                                                                                            {{__('discussion.like')}}| <a class="commentLikes" href="/forum/comment/likes/{{$comment->id}}"><span>{{\App\CommentReaction::where('article_id', $comment->id)->count()}}</span>
                                                                                        </td>
                                                                                        <td style="@if($locale=="en") text-align: right; @else text-align: left; @endif">
                                                                                            <a class="fa fa-reply" data-toggle="collapse" href="#demo{{$comment->id}}" id="reply"> {{__("discussion.reply")}} | </a><span class="rCount">{{count($replyToComment)}}</span>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                                <div id="demo{{$comment->id}}" class="collapse">
                                                                                    <hr>
                                                                                    <form action="/replytocomment_add" method="post" class="replyform form-inline">
                                                                                        {{csrf_field()}}
                                                                                        <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                                        <input type="hidden" name="article_id" value="{{$article->id}}">
                                                                                        <textarea class="form-control" style="width:78%;" placeholder="{{__("discussion.replytothiscomment")}}" name="content" rows="1"></textarea>
                                                                                        <button type="submit" class="btn btn-default">{{__('discussion.submitreply')}}</button>
                                                                                    </form>
                                                                                    <hr>
                                                                                    @foreach($replyToComment as $reply)
                                                                                        <ul class="media-list">
                                                                                            <li class="media media-replied">
                                                                                                <a class="pull-left profile_image" href="{{ url('/users/profile/ajax/' . $reply->user_id )}}">
                                                                                                    <img class="media-object img-circle" src="@if($reply->user->image){{$reply->user->image}}@else @if($reply->user->gender==1) profile_pic/profile_simple.png @else profile_pic/profile_simple_gril.png @endif @endif" alt="profile">
                                                                                                </a>
                                                                                                <div class="media-body">
                                                                                                    <div class="well well-sm" style="background-color: white">
                                                                                                        <table width="100%">
                                                                                                            <tr>
                                                                                                                <td>
                                                                                                                    <h5 class="media-heading text-uppercase reviews">{{$reply['user']['name']. ' ', $reply['user']['last_name']}}</h5>
                                                                                                                </td>
                                                                                                                <td style="text-align: @if($locale=='en') right @else left @endif;">
                                                                                                                    <a class="fa fa-edit editReply @if($reply->user_id != Auth::user()->id and Auth::user()->user_type!=1) hidden @endif" href=" {{ url('/edit/your/reply/' . $reply->id )}}"></a>
                                                                                                                    <a class="fa fa-fw fa-trash-o deleteReply @if($reply->user_id != Auth::user()->id and Auth::user()->user_type!=1) hidden @endif" href=" {{ url('/delete/your/reply/' . $reply->id )}}"></a>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </table>
                                                                                                        <ul class="media-date text-uppercase reviews list-inline">
                                                                                                            <p style="color: #0b97c4; font-size: 14px;">{{$reply->reply_date}}</p>
                                                                                                        </ul>
                                                                                                        <p class="media-comment" id="reply{{$reply->id}}">
                                                                                                            {!! $reply->content !!}
                                                                                                        </p>
                                                                                                        <a class="fa fa-thumbs-o-up likeReply" href="{{ url('/forum/article/likereply/' . $reply->id)}}"
                                                                                                           style="@if(\App\ReplyReaction::where('reply_id', $reply->id)->where('user_id', Auth::user()->id)->count() > 0) color: #0b97c4; @else color: #32383e; @endif">
                                                                                                        </a>
                                                                                                        {{__('discussion.like')}} | <a class="replyLikes" href="/forum/reply/likes/{{$reply->id}}"><span>{{count($reply['likes'])}}</span></a>

                                                                                                    </div>
                                                                                                </div>
                                                                                            </li>
                                                                                        </ul>
                                                                                    @endforeach
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endforeach
                                                            </ul>
                                                            <a id="next" href="javascript:void;">{{__('discussion.more_comments')}}</a>
                                                        </div>
                                                    </div>


                                                </div>
                                                <!--Edit post modal-->
                                                <div id="editArticleDiv" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
                                                                <span>
                                                                    Edit Article
                                                                </span>
                                                            </div>
                                                            <div class="modal-body" style="padding: 2em;">
                                                                <form id="edited_article" class="form center-block" style="padding: 0em;" action="{{ url('/forum/update_article') }}" method="post" enctype="multipart/form-data">
                                                                    {{ csrf_field() }}
                                                                    <input type="hidden" name="article_id" id="edited_article_id" value="">
                                                                    <br>
                                                                    <div class="panel-group">
                                                                        <label for="title">{{__('discussion.title')}}</label>
                                                                        <input type="text" name="title" id="edited_title" placeholder="{{__('discussion.article_title')}}" value="{{ old('title') }}" class="form-control" required>
                                                                        @if($errors->has('title'))
                                                                            <div class="error">
                                                                                {{ $errors->first('title') }}
                                                                            </div>
                                                                        @endif
                                                                    </div>

                                                                    <div class="panel-group">
                                                                        <label for="body">{{__('discussion.article')}}</label>
                                                                        <textarea name="body" class="form-control editor" id="edited_body" rows="8" cols="80" required></textarea>
                                                                        @if($errors->has('body'))
                                                                            <div class="error">
                                                                                {{ $errors->first('body') }}
                                                                            </div>
                                                                        @endif
                                                                    </div>

                                                                    <div class="panel-group">
                                                                        <label for="attachment">{{__('discussion.attachment')}} </label>
                                                                        <input type="file" name="attachment" id="edited_attachment" class="form-control">
                                                                        <p class="help-block">
                                                                            <i class="fa fa-fw fa-info-circle" aria-hidden="true"></i>
                                                                            {{__('discussion.uploadable')}}
                                                                        </p>
                                                                        @if($errors->has('attachment'))
                                                                            <div class="error">
                                                                                {{ $errors->first('attachment') }}
                                                                            </div>
                                                                        @endif
                                                                    </div>

                                                                    <!--this div temporary hidden -->
                                                                    <div id="exist_attachment" class="panel-group hidden">
                                                                        Attachment File Exist
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <button type="submit" class="btn btn-primary">
                                                                            <i class="fa fa-floppy-o" aria-hidden="true"></i>
                                                                            {{__('discussion.submit')}}
                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- main col right -->
                                            <div class="col-sm-5">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        @php
                                                            $general_cat = DB::table('forum_categories')->where('visible', 1)->where('id', 1)->first();
                                                        @endphp
                                                        <h4 id="cat_title">
                                                            @if($locale == 'en')
                                                                {{ $general_cat->en_title }}
                                                            @elseif($locale == 'da')
                                                                {{ $general_cat->da_title }}
                                                            @else
                                                                {{ $general_cat->ps_title }}
                                                            @endif
                                                        </h4>
                                                    </div>
                                                    <div class="panel-body">
                                                        @php
                                                            $articles = DB::table('forum_articles')->where('category_id', 1)
                                                                ->join('users', 'users.id', '=', 'forum_articles.user_id')
                                                                ->select('forum_articles.*', 'users.name as username')
                                                                ->orderBy('id', 'desc')->limit(10)
                                                                ->get();
                                                        @endphp
                                                        <div class="table-responsive">
                                                            <div id="article_delete_conformation"> </div>
                                                            <table class="table" >
                                                                <thead>
                                                                <tr>
                                                                    <th>{{__('discussion.title')}}</th>
                                                                    <th>@lang('discussion.date')</th>
                                                                    <th >{{__('discussion.author')}}</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody id="articles">
                                                                    @foreach($articles as $article)
                                                                        <tr>
                                                                            <td>
                                                                                <a class="article" href="forum/article/{{$article->id}}">
                                                                                    <i class="fa fa-fw fa-file-text-o" aria-hidden="true"></i>
                                                                                    {{ $article->title }}
                                                                                    @if($article->attachment)
                                                                                        <i class="fa fa-fw fa-paperclip" aria-hidden="true"></i>
                                                                                    @endif
                                                                                </a>
                                                                            </td>
                                                                            <td style="color:gray; font-size:12px;">{{ $article->created_at }}</td>
                                                                            <td>
                                                                                <a class="profile_image" href="{{ url('/users/profile/ajax/' . $article->user_id) }}" style="color:#444; font-size:12px;" target="_blank">
                                                                                    <i class="fa fa-fw fa-user-o" aria-hidden="true"></i>
                                                                                    {{ $article->username }}
                                                                                </a>
                                                                            </td>
    
                                                                            @if($article->user_id==Auth::user()->id or Auth::user()->user_type==1)
                                                                                <td class="text-center"><a class="del" href="/deleteforum/{{ $article->id}}"><i class="fa fa-fw fa-trash-o" title="Delete this record"></i>
                                                                                    </a></td>
                                                                            @else
                                                                            @endif
                                                                        </tr>
                                                                    @endforeach
                                                            
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr><td colspan="4"><a href="/forum/readMore/{{$articles['9']->category_id}}/{{$articles['9']->id}}" id="read_more">{{__('discussion.more_discussions')}}</a></td></tr>
                                                                </tfoot>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <!--/row-->

                                    </div><!-- /col-9 -->
                                </div><!-- /padding -->
                            </div>
                            <!-- /main -->
                        </div>
                    </div>
                </div>

                <!--user modal-->
                <div id="userModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                                {{__('nav.user_profile')}}
                            </div>
                            <div id="user_profile" class="modal-body" style="padding: 2em;">

                            </div>
                        </div>
                    </div>
                </div>

                <!--post modal-->
                <div id="postModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
                                <span id="category_title">
                                    @if($locale == 'en')
                                        {{ $general_cat->en_title }}
                                    @elseif($locale == 'da')
                                        {{ $general_cat->da_title }}
                                    @else
                                        {{ $general_cat->ps_title }}
                                    @endif
                                </span>
                            </div>
                            <div class="modal-body" style="padding: 2em;">
                                <form id="add_article" class="form center-block" style="padding: 0em;" action="{{ url('/forum/save_article') }}" method="post" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="category_id" value="1">
                                    <br>
                                    <div class="panel-group">
                                        <label for="title">{{__('discussion.title')}}</label>
                                        <input type="text" name="title" id="title" placeholder="{{__('discussion.article_title')}}" value="{{ old('title') }}" class="form-control" required>
                                        @if($errors->has('title'))
                                            <div class="error">
                                                {{ $errors->first('title') }}
                                            </div>
                                        @endif
                                    </div>

                                    <div class="panel-group">
                                        <label for="body">{{__('discussion.article')}}</label>
                                        <textarea name="body" id="body" class="form-control editor" rows="8" cols="80" required>{{ old('body')}}</textarea>
                                    </div>

                                    <!--this div temporary hidden -->
                                    <div class="panel-group">
                                        <label for="attachment">{{__('discussion.attachment')}} </label>
                                        <input type="file" name="attachment" id="attachment" value="{{ old('attachment')}}" class="form-control">
                                        <p class="help-block">
                                            <i class="fa fa-fw fa-info-circle" aria-hidden="true"></i>
                                            {{__('discussion.uploadable')}}
                                        </p>
                                        @if($errors->has('attachment'))
                                            <div class="error">
                                                {{ $errors->first('attachment') }}
                                            </div>
                                        @endif
                                    </div>

                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fa fa-floppy-o" aria-hidden="true"></i>
                                            {{__('discussion.submit')}}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function(){
              var list = $("#comments li.countable");
              var numToShow = 5;
              var button = $("#next");
              var numInList = list.length;
              list.hide();
              button.hide();
              if (numInList > numToShow) {
                button.show();
              }
              list.slice(0, numToShow).show();
              $("#next").click(function(){
                  var showing = $("#comments li.countable").filter(':visible').length;
                  $("#comments li.countable").slice(showing - 1, showing + numToShow).fadeIn();
                  var nowShowing = $("#comments li.countable").filter(':visible').length;
                  if (nowShowing >= $("#comments li.countable").length) {
                    $("#next").hide();
                  }
              });
        
        });
    </script>
@endsection
