<?php

namespace App\Http\Controllers;

use App\Forum_articles;
use App\UserCoalition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use DB;
use App\User;
use App\Notification;

use App\Traits\SystemLogTrait;


class UserController extends Controller
{
  use SystemLogTrait;

  function __construct()
  {
    $this->middleware('auth');
  }


  public function dashboard()
  {
    $user = Auth::user();

    $coalitions = DB::table('user_coalitions')->where('user_coalitions.user_id', $user->id)
    ->join('coalitions', 'user_coalitions.coalition_id', '=', 'coalitions.id')
    ->select('coalitions.*')
    ->get();

    return view('user.dashboard', compact('user', 'coalitions'));
  }


  public function showNotifications() {
    $notifications = Notification::latest()->where('user_id', Auth::id())->get();

    return view('user.notifications', compact('notifications'));
  }

  public function deleteNotifications() {
    Notification::where('user_id', Auth::id())->delete();
    return redirect(url('/user/notifications'));
  }

  public function viewNotification($id) {
    $notification = Notification::find($id);
    $link = "";

    if ($notification->entity_type == 'forum') {
      $link = url('/forum');
    } else if ($notification->entity_type == 'resource') {
      $link = url('/resources');
    } else if ($notification->entity_type == 'announcement') {
      $link = url('/announcement/' . $notification->entity_id);
    } else if ($notification->entity_type == 'news') {
      $link = url('/news/' . $notification->entity_id);
    } else if ($notification->entity_type == 'admin/news') {
      $link = url('/admin/news/edit/' . $notification->entity_id);
    } else if ($notification->entity_type == 'cso_application') {
      $link = url('/admin/application/cso_personal/edit/' . $notification->entity_id);
    } else if ($notification->entity_type == 'individual_application') {
      $link = url('/admin/application/individual/edit/' . $notification->entity_id);
    } else if ($notification->entity_type == 'contactus') {
      $link = url('/admin/contact');
    } else if ($notification->entity_type == 'career') {
      $link = url('/jobs/'. $notification->entity_id);
    } else if ($notification->entity_type == 'report') {
      $link = url('/reports/');
    } 

    $notification->viewed = true;
    $notification->save();

    return redirect($link);
  }

  public function showProfile($user_id)
  {
    $user = User::findOrFail($user_id);
    $total_replies = DB::table('forum_replies')->where("user_id", $user_id)->count();
    $total_articles = DB::table('forum_articles')->where('user_id', $user_id)->count();

    return view('user.profile', compact('user', 'total_replies', 'total_articles'));
  }

  public function showProfileByAjax($user_id)
  {
      $user = User::with('articles', 'comments', 'replies')->findOrFail($user_id);
      $userType="";
      if(app()->getLocale()=="en"){
          $userType=DB::table("user_types")->where("id", $user->user_type)->value("en_title");
      }else if(app()->getLocale()=="da"){
          $userType=DB::table("user_types")->where("id", $user->user_type)->value("da_title");
      }else{
          $userType=DB::table("user_types")->where("id", $user->user_type)->value("ps_title");
      }
      $userCoalitions=UserCoalition::where('user_id', $user->id)->pluck('coalition_id')->all();
      $coalitions=DB::table("coalitions")->whereIn("id", $userCoalitions)->where('status', 2)->get();
      return response()->json(['user'=> $user, 'userType'=> $userType, 'coalitions'=> $coalitions]);
  }

  public function editProfile()
  {
    $user = DB::table('users')->where('id', Auth::id())->first();

    return view('user.edit_profile', compact('user'));
  }


  public function updateProfile(Request $request)
  {
    $this->validate($request, [
      'name' => 'required',
      'last_name' => 'required',
      'email' => 'required',
      'mobile' => 'required',
      'photo' => 'file|max:1024'
    ]);
    
    $old_photo=DB::table('users')->where('id', Auth::id())->first();
    if($request->photo){
        $file = $request->file('photo');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'profile_pic/';
        $filename = $filename . '.' . $fileExt;
        $path=$file->move($destinationPath, $filename);
        
        DB::table('users')->where('id', Auth::id())
            ->update([
                'image' => $path
            ]);
        
        if($old_photo->image and file_exists($old_photo->image)){
            unlink($old_photo->image);
        }
    }


    DB::table('users')->where('id', Auth::id())
    ->update([
      'name' => $request->name,
      'last_name' => $request->last_name,
      'email' => $request->email,
      'mobile' => $request->mobile
    ]);

    $this->createLog("User updated their profile.");
    return redirect()->back()->with('msg', 'Your profile was successfully updated.');
  }


  public function changePassword()
  {
    $user = DB::table('users')->where('id', Auth::id())->first();

    return view('user.change_password', compact('user'));
  }


  public function updatePassword(Request $request)
  {
    $this->validate($request, [
      'current_password' => 'required',
      'newpassword' => 'required|min:6|confirmed',
    ]);


    if (Hash::check($request->current_password, Auth::user()->getAuthPassword())) {
     $user = Auth::user();
     $user->password = Hash::make($request->newpassword);
     $user->save();

     $this->createLog("User changed their password.");
     return redirect()->back()->with('msg', 'Your password was successfully changed.');

   } else {
     return back()->with('msg', 'The provided current password is incorrect.');
   }

 }
 public function updatePasswordajax(Request $request)
 {
   $this->validate($request, [
     'current_password' => 'required',
     'newpassword' => 'required|min:6|confirmed',
   ]);


   if (Hash::check($request->current_password, Auth::user()->getAuthPassword())) {
    $user = Auth::user();
    $user->password = Hash::make($request->newpassword);
    $user->save();

    $this->createLog("User changed their password.");
    return response()->json(['msg'=> 'Your password was successfully changed.', 'result'=> true]);

  } else {
    return response()->json(['msg'=> 'The provided current password is incorrect.', 'result'=> false]);
  }

}

public function updateProfileAjax(Request $request)
{
  $this->validate($request, [
    'name' => 'required',
    'last_name' => 'required',
    'email' => 'required',
    'mobile' => 'required',
    'photo' => 'file|max:1024'
  ]);
  
  $old_photo=DB::table('users')->where('id', Auth::id())->first();
  if($request->photo){
      $file = $request->file('photo');
      $filename         = str_random(12);
      $fileExt          = $file->getClientOriginalExtension();
      $destinationPath  = 'profile_pic/';
      $filename = $filename . '.' . $fileExt;
      $path=$file->move($destinationPath, $filename);
      
      DB::table('users')->where('id', Auth::id())
          ->update([
              'image' => $path
          ]);
      
      if($old_photo->image and file_exists($old_photo->image)){
          unlink($old_photo->image);
      }
  }


  DB::table('users')->where('id', Auth::id())
  ->update([
    'name' => $request->name,
    'last_name' => $request->last_name,
    'email' => $request->email,
    'mobile' => $request->mobile
  ]);
  $currentprofile=User::where('id', Auth::id())->first();

  $this->createLog("User updated their profile.");
  return response()->json(['msg'=> 'Your profile was successfully updated.', 'result'=> false,'currentprofile'=>$currentprofile]);
}

public function getUserPermission()
{
  $permissions=DB::table('user_permissions')->where('user_id', Auth::id())->first();
  $notifications=  Notification::whereIn('entity_type', ['casts','forum'])->where('user_id', Auth::id())->where('viewed', false)->count();
 $user=Auth::user();
  return response()->json(['permissions'=>$permissions,'notifications'=>$notifications,'user'=>$user]);

}
}
