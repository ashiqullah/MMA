export class ReplyModel {
    id: number;
    postedby: string;
    postedByImage: string;
    postedOn: string;
    postedByGender: number;
    content: string;
    totalLikes: number;
    isLiked: boolean;
    postedByid: number;
    hasAccessToEdit : boolean;



}