import { Component, OnInit } from '@angular/core';
import { UserProvider } from '../providers/user/user';
import { ModalController, NavParams } from '@ionic/angular';
import { Service } from '../settings/Laravel';
import { UserProfilePage } from '../user-profile/user-profile.page';

@Component({
  selector: 'app-like-users',
  templateUrl: './like-users.page.html',
  styleUrls: ['./like-users.page.scss'],
})
export class LikeUsersPage implements OnInit {
  users:  any[];
  id:any;
  type:any;
  ServerUrl: string;
  Maleimage: string;
  Femaleimage: string;

  constructor(
    private userService: UserProvider,
    public modalController: ModalController,
    public navParams: NavParams,
  ) {
    this.ServerUrl = Service.url;
    this.Maleimage = Service.maleImageUrl;
    this.Femaleimage = Service.femaleImageUrl;
    this.users=[];
   }

  ngOnInit() {
    this.id     = this.navParams.get('typeid');
    this.type = this.navParams.get('type');
    this.userService.likeUsers(this.id).then((response: any) => {
      this.users=response;  
      console.log(response);
      });

  }
  dismiss() {
    this.modalController.dismiss();
}
async presentModal(profileId: number) {
  const modal = await this.modalController.create({
    component: UserProfilePage,
    componentProps: { value: profileId }
  });
  return await modal.present();
}

}
