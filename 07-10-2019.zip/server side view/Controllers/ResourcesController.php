<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Resources;
use App\User;
use App\ContactGroup;
use App\UserContactGroup;
use Illuminate\Support\Facades\Auth;
use App\Traits\SystemLogTrait;
use App\SystemLog;

use App\Traits\NotificationTrait;

class ResourcesController extends Controller
{
  use SystemLogTrait;
  use NotificationTrait;

  function __construct()
  {
    $this->middleware('auth', ['except' => [
            'category'
        ]]);
  }

    # Home
  public function home()
  {
     

    //   $categories = DB::table('resources_categories')->where('parent', 0)
    // ->get();
      // Categories
    // $categories = DB::table('resources_categories')
    // ->get();

    $categories = DB::select('select * from resources_categories where parent=0 group by en_title');

    // Coalitions
    $contact_groups = ContactGroup::get();
    return view('resources.home', compact('categories', 'contact_groups'));
  }

    # Category
  public function category($slug)
  {
    $lang=app()->getLocale();  
      
    # Category
    $category = DB::table('resources_categories')->where('slug', $slug)->first();
    $categoryid = $category->id;
    if($category->parent!=0){
        $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
        join resources on users.id = resources.user_id 
        join resources_categories on resources.slug_id = resources_categories.id where resources.category_id = '$categoryid' and resources.lang = '$lang'  ORDER BY resources.id desc;");
    }else{
        $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
        join resources on users.id = resources.user_id 
        join resources_categories on resources.slug_id = resources_categories.id where resources.slug_id = '$categoryid' and resources.lang = '$lang' ORDER BY resources.id desc;");
    }
    
    return view("resources.category", compact('resources', 'category'));
  }

    // Sub Category
  public function sub_cats($parent_id)
  {
    $categories = DB::table('resources_categories')->where('parent', $parent_id)->get();

    return view('resources.sub_cats', compact('categories'));
  }

  /* Add Resource */
  public function add_resource(Request $request)
  {
      // Validate User Inputs
   $this->validate($request, [
    'title' => 'required|min:3',
    'category' => 'required',
    'resource_type' => 'required',
    'sharewith' => 'required',
    'image' => 'file|max:1024'
  ]);


      // Add Initial Values
   $resource_id = DB::table('resources')->insertGetId([

    'title' => $request->title,
    'category_id' => $request->sub_cat,
    'sharewith' => $request->sharewith,
    'user_id' => Auth::id(),
    'lang' => $request->lang,
    'status' => 1,
    'slug_id' =>$request->category

  ]);

      // Initalized Resource Type
   $resource_type = $request->resource_type;

      // If Resource Type is link
   if($resource_type == 'link')
   {
    DB::table('resources')->where('id', $resource_id)->update([
      'link' => $request->link,
      'file' => null
    ]);
  }
  else if($resource_type == 'file')
  {
      if($request->file('file')){
        $file= $request->file('file');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'upload/resources/';
        $filename = $filename . '.' . $fileExt;
        $path=$file->move($destinationPath, $filename);
        
        DB::table('resources')->where('id', $resource_id)->update([
          'file' => $path,
          'link' => null
        ]);
      }
      if($request->file('image')){
        $file= $request->file('image');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'upload/resources/';
        $filename = $filename . '.' . $fileExt;
        $path=$file->move($destinationPath, $filename);
        
        DB::table('resources')->where('id', $resource_id)->update([
          'image' => $path,
        ]);
      }

  }
  
    # Notification
    $users = UserContactGroup::where('contact_group_id', $request->sharewith)->pluck('user_id')->all();
		$emails = User::whereIn('id', $users)->where('status', 1)->pluck('email')->all();
		foreach( $emails as $email){
	        $this->sendNotificationToApplicant($email, "A new item has been added in the Resources");
		}
		
		//create system notification
		foreach($users as $user){
	        $this->createNotification($user, "  ".$this->getFullName(Auth::id()). " added a new Resources ", "resource", $resource_id);
		}

    $this->createLog("Added a new item in Resources.");

      // Return
  return redirect('/resources')->with('msg', 'Your resource has been sent and pending for the review.');


}


function categoryItems($id){

  $items =DB::select("select resources.*, users.* from resources join users on resources.user_id = users.id where category_id='$id'");

  return view("resources.category_items", ['items'=>$items]);
}

function categoryItemsAjax(){

 // $items =DB::select("select resources.*, users.* from resources join users on resources.user_id = users.id where category_id=1");
/*   $category = DB::table('resources_categories')->where('id', $category_id)->first();

  return response()->json(['category' => 'category', 'articles' => $articles]); */

  $slug="general";
  $lang="en";
  $categories = DB::select('select * from resources_categories where parent=0 group by en_title');



  $category = DB::table('resources_categories')->where('slug', $slug)->first();
  $categoryid = $category->id;
  if($category->parent!=0){
      $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
      join resources on users.id = resources.user_id 
      join resources_categories on resources.slug_id = resources_categories.id where resources.category_id = '$categoryid' and resources.lang = '$lang'  ORDER BY resources.id desc;");
  }else{
      $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
      join resources on users.id = resources.user_id 
      join resources_categories on resources.slug_id = resources_categories.id where resources.slug_id = '$categoryid' and resources.lang = '$lang' ORDER BY resources.id desc;");
  }


  return response()->json(['category' => $categories, 'Items' => $resources]);
}

function categoryItemsAjaxByslug($slug){

  // $items =DB::select("select resources.*, users.* from resources join users on resources.user_id = users.id where category_id=1");
 /*   $category = DB::table('resources_categories')->where('id', $category_id)->first();
 
   return response()->json(['category' => 'category', 'articles' => $articles]); */
 
   
   $lang="en";
 
 
 
   $category = DB::table('resources_categories')->where('slug', $slug)->first();
   $categoryid = $category->id;
   if($category->parent!=0){
       $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
       join resources on users.id = resources.user_id 
       join resources_categories on resources.slug_id = resources_categories.id where resources.category_id = '$categoryid' and resources.lang = '$lang'  ORDER BY resources.id desc;");
   }else{
       $resources = DB::select("select resources_categories.*,users.*, resources.* from users 
       join resources on users.id = resources.user_id 
       join resources_categories on resources.slug_id = resources_categories.id where resources.slug_id = '$categoryid' and resources.lang = '$lang' ORDER BY resources.id desc;");
   }
 
 
   return response()->json($resources);
 }


}
