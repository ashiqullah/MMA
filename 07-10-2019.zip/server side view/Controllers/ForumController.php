<?php

namespace App\Http\Controllers;

use App\ArticleReaction;
use App\CommentReaction;
use App\ContactGroup;
use App\ReplyReaction;
use App\ReplyToComment;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Forum_articles;
use App\Forum_replies;
use App\Traits\NotificationTrait;
use App\Notification;
use App\User;
use App\UserContactGroup;
use Carbon\Carbon;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;

class ForumController extends Controller
{
  use NotificationTrait;

  function __construct()
  {
    $this->middleware('auth');
  }



    # Categories
    public function allcategories($category_id)
    {
        # Category Details
        
        if(Auth::user()->user_type==1) {
          $categories = DB::table('forum_categories')->orderBy('location', 'asc')
              ->where('visible', 1)->orWhere('id', 17)
              ->get();
      }else{
          $categories = DB::table('forum_categories')->orderBy('location', 'asc')
              ->where('visible', 1)
              ->get();
      }
        /* $found = DB::table('user_coalitions')->where('user_id', Auth::user()->id);
    
        $categories = DB::table('forum_categories')->get(); */
  
        $items = array();
foreach($categories as $category) {
  $found = DB::table('user_coalitions')->where('user_id', Auth::user()->id)
  ->where('coalition_id', $category->coalition_id)
  ->count();

  /* General Category */
  if($category->id == 1 or $category->id == 17)
  {
    $found = 1;
  }
  if($found==1)
  {
    $items[] = $category;

  }
}
      return response()->json($items);
    }






    # Home Page
  public function home()
  {
    if(Auth::user()->user_type==1) {
        $categories = DB::table('forum_categories')->orderBy('location', 'asc')
            ->where('visible', 1)->orWhere('id', 17)
            ->get();
    }else{
        $categories = DB::table('forum_categories')->orderBy('location', 'asc')
            ->where('visible', 1)
            ->get();
    }
    Forum_articles::where('category_id', 1)->orderBy('id', 'DESC')->first()->increment('hits');
    return view('forum.home', compact('categories'));
  }

    # Category
  public function category($category_id)
  {
      # Category Details
    $category = DB::table('forum_categories')->where('id', $category_id)
    ->first();

      # User Permission
    $found = DB::table('user_coalitions')->where('user_id',Auth::user()->id)/* 11825*/
    ->where('coalition_id', $category->coalition_id)
    ->count();
    if(!$found == 1 and $category_id != 17)
    {
      if($category_id != 1)
      {
        return response()->json("");
      }
    }

      # List of Articles
    $articles = Forum_articles::with('user', 'comments.replies.likes', 'comments.replies.user', 'comments.likes', 'comments.user', 'likes', 'replies')->where('category_id', $category_id)->orderBy('id', 'DESC')->limit(10)->get();
    $article = Forum_articles::where('category_id', $category_id)->orderBy('id', 'DESC')->first();
    if($article!=null){
        $article->increment('hits');
    }
    return response()->json(['category' => $category, 'articles' => $articles]);
  }

    # Article
  public function article(Request $request, $article_id)
  {
      $articles = Forum_articles::with('user', 'comments.replies.likes', 'comments.replies.user', 'comments.likes', 'comments.user', 'likes', 'replies')->find($article_id);
      $article = Forum_articles::find($article_id);
        if($article!=null){
            $article->increment('hits');
        }
      return response()->json(['category' => 'category', 'articles' => $articles]);
  }

    # Edit Article
  public function edit_article($article_id)
  {
      # Article
    if(Auth::user()->user_type==1){
        $article = DB::table('forum_articles')->where('id', $article_id)->first();
    }  else{
        $article = DB::table('forum_articles')->where('id', $article_id)->where('user_id', Auth::user()->id)->first();
    }

      # if Article not found go back
    if(count($article) == 0)
    {
      return response()->json('');
    }

    return response()->json($article);
  }



// like comment

  function likecomment($id){

    $liked = DB::table('comment_reactions')->where('article_id', $id)->where('user_id', Auth::id())->first();

    if ($liked != null) {
      DB::table('comment_reactions')->where('article_id', $id)
      ->where('user_id', Auth::id())
      ->where('btnlike', 1)
      ->delete();

      $count = DB::table('comment_reactions')->where('article_id', $id)->get()->count();

      return response()->json(['count'=> $count, 'like'=> 'unliked']);

    } else {
      DB::table('comment_reactions')->insert([
        'btnlike' => 1,
        'user_id' => Auth::id(),
        'article_id' => $id
      ]);

      $count = DB::table('comment_reactions')->where('article_id', $id)->get()->count();

      return response()->json(['count'=> $count, 'like'=> 'liked']);

    }
  }

  function likeReply($id){
        $liked = DB::table('reply_reactions')->where('reply_id', $id)->where('user_id', Auth::id())->first();

        if ($liked != null) {
            DB::table('reply_reactions')->where('reply_id', $id)
                ->where('user_id', Auth::id())
                ->where('btnlike', 1)
                ->delete();

            $count = DB::table('reply_reactions')->where('reply_id', $id)->get()->count();

            return response()->json(['count'=> $count, 'like'=> 'unliked']);

        } else {
            DB::table('reply_reactions')->insert([
                'btnlike' => 1,
                'user_id' => Auth::id(),
                'reply_id' => $id
            ]);

            $count = DB::table('reply_reactions')->where('reply_id', $id)->get()->count();

            return response()->json(['count'=> $count, 'like'=> 'liked']);

        }
  }



  /* Update Articles */
  public function update_article(Request $request)
  {
    $this->validate($request, [
      'title' => 'required',
      'body' => 'required',
      'attachment' => 'nullable|file'
    ]);

    $title = $request->title;
    $body = $request->body;
    
    //Storing Attachment
    $path="";
    if($request->attachment!=null){
        if($request->file('attachment')){
            $file= $request->file('attachment');
            $filename         = str_random(12);
            $fileExt          = $file->getClientOriginalExtension();
            $destinationPath  = 'files/discussions/';
            $filename = $filename . '.' . $fileExt;
            $path=$file->move($destinationPath, $filename);
        }
    }
    if($path!=""){
        $exist=Forum_articles::where('id', $request->article_id)->first();
        if(file_exists($exist->attachment)){
            unlink($exist->attachment);
        }
        Forum_articles::where('id', $request->article_id)->update(
            [
                'title' => $title,
                'body' => $body,
                'attachment' => $path,
            ]);
    }else{
        Forum_articles::where('id', $request->article_id)->update(
            [
                'title' => $title,
                'body' => $body,
            ]);
    }
    $article=Forum_articles::with('user')->where('id', $request->article_id)->first();
    return response()->json($article);
  }

  /* Delete Artilce */
  public function delete_article($id)
  {
    $article = DB::table('Forum_articles')->where('user_id', Auth::user()->id)
    ->where('id', $id)
    ->first();

    if(!$article)
    {
      return Redirect::back();
      exit();
    }

      # Category ID
    $category_id = $article->category_id;

      # Delete the article
    DB::table('forum_replies')->where('article_id', $id)->delete();
    DB::table('Forum_articles')->where('id', $id)->delete();

    return Redirect::to('forum/category/' . $category_id);

  }

    # Save Article
  public function save_article(Request $request)
  {
    $this->validate($request, [
      'title' => 'required',
      'body' => 'required',
      'attachment' => 'nullable|file'
    ]);
    $exist=Forum_articles::where('title', $request->title)->get();
    if(count($exist)> 0){
        return response()->json('This discussion is already exists!');
    }
    $title = $request->title;
    $body = $request->body;
    $user_id = Auth::user()->id;
    $category_id = $request->category_id;
    $hits = 1;

    //Storing Attachment
    $path="";
    if($request->file('attachment')){
        $file= $request->file('attachment');
        $filename         = str_random(12);
        $fileExt          = $file->getClientOriginalExtension();
        $destinationPath  = 'files/discussions/';
        $filename = $filename . '.' . $fileExt;
        $path=$file->move($destinationPath, $filename);
    }

    $article = new Forum_articles;
    $article->title = $title;
    $article->body = $body;
    $article->user_id = $user_id;
    $article->category_id = $category_id;
    $article->hits = $hits;
    $article->attachment = $path;
    $article->save();
    
    $coalition_id=DB::table('forum_categories')->where('id', $article->category_id)->first();
    if($coalition_id->coalition_id==0) {
        $contact_group = ContactGroup::with('users')->where('coalition_id', 0)->first();
    }elseif ($coalition_id->coalition_id==17){
        $contact_group = ContactGroup::with('users')->where('coalition_id', 17)->first();
    }else{
        $contact_group = ContactGroup::with('users')->where('coalition_id', $coalition_id->coalition_id)->first();
    }
    // email system
    /* if(isset($contact_group) and !empty($contact_group)){
    foreach( $contact_group->users as $user){
            $user=User::find($user->user_id);
            if(isset($user) and !empty($user)) {
    	        $this->sendNotificationToApplicant($user->email, " ".Auth::user()->name ." ". Auth::user()->last_name." added a new title '$title' on KMP Discussion Forum in ". $coalition_id->en_title. " category");
                // log system
                $this->createNotification($user->id, $this->getFullName($article->user_id)." added a new post to MKMP in ". $coalition_id->en_title. " category", "forum", $article->id);
            }
        }
    } */
    
    $article=Forum_articles::with('user', 'comments', 'likes', 'replies')->where('id', $article->id)->first();
    return response()->json($article);
  }

  /* Save Reply */
  public function save_reply(Request $request)
  {
    $this->validate($request, [
      'reply' => 'required|min:2'
    ]);

    $user_reply = $request->reply;
    $user_id = Auth::user()->id;
    $article_id = $request->article_id;

    $reply = new Forum_replies;
    $reply->reply = $user_reply;
    $reply->user_id = $user_id;
    $reply->article_id = $article_id;
    $reply->save();

    $count = DB::table('forum_replies')->where('article_id', $article_id)->get()->count();
    $reply = Forum_replies::with('user', 'replies', 'likes', 'article')->find($reply->id);
    $owner = Forum_articles::find($article_id);

    $this->createNotification($owner->user_id, $reply->user->name . ' ' . $reply->user->last_name
     . ' replied to your article in Discussion Forum', 'forum', $request->article_id);


    //return response()->json($reply);
    return response()->json(['comment'=> $reply, 'totalcomments'=>$count]);

  }

  public function getCommentsajax($article_id)
  {
    $comments = Forum_replies::with('user', 'replies.likes', 'replies.user', 'likes', 'replies')->where('article_id', $article_id)->orderBy('id', 'DESC')->limit(5)->get();;

    return response()->json($comments);

  }

  public function getCommentsajaxMore($article_id,$id)
  {
    $comments = Forum_replies::with('user', 'replies.likes', 'replies.user', 'likes', 'replies')->where('id', '<', $id)->where('article_id', $article_id)->orderBy('id', 'DESC')->limit(5)->get();;

    return response()->json($comments);

  }

  /* Comments */
  public function comments($article_id)
  {

      // Get All Replies
    $replies = DB::table('forum_replies')->where('forum_replies.article_id', $article_id)
    ->orderBy('id', 'asc')
    ->join('users', 'users.id', '=', 'forum_replies.user_id')
    ->select('forum_replies.*', 'users.name as username')

    ->where('parent_id', 0)
    ->get();

      // Return to view
    return view('forum.comments', compact('replies'));
  }

  /* Edit comment */
  public function edit_comment($comment_id)
  {
    if(Auth::user()->user_type==1){
        $comment = DB::table('forum_replies')->find($comment_id);
    }else{
        $comment = DB::table('forum_replies')->where('id', $comment_id)
        ->where('user_id', Auth::user()->id)
        ->first();
    }
   
    return response()->json($comment);
  }

  /* Update comment */
  public function update_comment(Request $request)
  {
    $this->validate($request, [
      'reply' => 'required|min:3'
    ]);

    $comment = Forum_replies::findOrFail($request->id);

    $comment->reply = $request->reply;
    $comment->lock_status = 1;
    $comment->save();

    return response()->json($comment);
  }

    /* Update reply */
    public function update_reply(Request $request)
    {
        $this->validate($request, [
            'reply' => 'required|min:3'
        ]);

        DB::table('replytocomment')->where('id', $request->id)->update(['content' => $request->reply]);
        $reply = ReplyToComment::find($request->id);

        return response()->json($reply);
    }

  /* Delete User Comment */
  public function delete_usercomment($comment_id)
  {
    if(Auth::user()->user_type==1) {
        // Find Comment with respect to its user and delete it
        $comment=Forum_replies::with('replies', 'likes')->find($comment_id);
    }else{
        $comment=Forum_replies::with('replies', 'likes')->where('user_id', Auth::user()->id)->where('id', $comment_id)->first();
    }
    if($comment){
        foreach ($comment->likes as $like){
            CommentReaction::find($like->id)->delete();
        }
        foreach ($comment->replies as $reply){
            $replyToComment= ReplyToComment::with('likes')->find($reply->id);
            foreach ($replyToComment->likes as $like){
                ReplyReaction::find($like->id)->delete();
            }
            ReplyToComment::find($reply->id)->delete();
        }
        Forum_replies::find($comment->id)->delete();
    }
      // Return back to the view
    return response()->json($comment);
  }

  /* Delete Comment */
  public function delete_comment($comment_id)
  {
    if(!(Auth::user()->id == 1))
      {
        echo "Access Denied!";
        exit();
      }

      $comment = Forum_replies::findOrFail($comment_id);
      $article_id = $comment->article_id;
      $result = $comment->delete();

      return response()->json($result);
    }



    public function likeArticle($article_id)
    {
      $liked = DB::table('article_reactions')->where('article_id', $article_id)->where('user_id', Auth::id())->first();

      if ($liked != null) {
        DB::table('article_reactions')->where('article_id', $article_id)
        ->where('user_id', Auth::id())
        ->where('btnlike', 1)
        ->delete();

        $article = Forum_articles::with('likes')->find($article_id);
        return response()->json(['likes'=> count($article->likes), 'like'=> 'unliked']);

      } else {
        DB::table('article_reactions')->insert([
          'btnlike' => 1,
          'user_id' => Auth::id(),
          'article_id' => $article_id
        ]);

        $article = Forum_articles::with('user', 'likes')->find($article_id);

        $this->createNotification($article->user_id, $article->user->name . ' ' . $article->user->last_name
         . ' liked your article in Discussion Forum', 'forum', $article->id);
        return response()->json(['likes'=> count($article->likes), 'like'=> 'liked']);
      }

    }

    /* Save Ajax Reply */
    public function save_ajaxreply(Request $request)
    {
      // Comment ID
      $comment_id = $request->comment_id;

      // Get Comment
      $comment = DB::table('forum_replies')->where('id', $comment_id)->first();

      // Article ID
      $article_id = $comment->article_id;

      // User ID
      $user_id = Auth::id();

      // Insert Forum Reply
      DB::table('forum_replies')->insert([
        'article_id' => $article_id,
        'user_id' => $user_id,
        'reply' => $request->comment,
        'parent_id' => $comment_id
      ]);

      // Return Response Back
      return response()->json(['status', 'done']);

    }


// delete from forum
    function deleteforum($id){
        $article=Forum_articles::with('notifications', 'comments', 'likes')->find($id);
        $title=$article->title;
        $id= $article->id;
        if(Auth::user()->id==$article->user_id or Auth::user()->user_type==1) {
            foreach ($article->notifications as $not) {
                Notification::find($not->id)->delete();
            }
            foreach ($article->likes as $like) {
                ArticleReaction::find($like->id)->delete();
            }
            foreach ($article->comments as $comment) {
                $forum_replies=Forum_replies::with('replies', 'likes')->find($comment->id);
                foreach ($forum_replies->likes as $like){
                    CommentReaction::find($like->id)->delete();
                }
                foreach ($forum_replies->replies as $reply){
                   $replyToComment= ReplyToComment::with('likes')->find($reply->id);
                   foreach ($replyToComment->likes as $like){
                       ReplyReaction::find($like->id)->delete();
                   }
                   ReplyToComment::find($reply->id)->delete();
                }
                Forum_replies::find($comment->id)->delete();
            }
            if (file_exists($article->attachment)) {
                unlink($article->attachment);
            }
            Forum_articles::find($article->id)->delete();
            $articles = Forum_articles::with('user','comments.replies.likes', 'comments.replies.user', 'comments.likes', 'comments.user', 'likes', 'replies')
                ->where('category_id', $article->category_id)->orderBy('id', 'DISC')->first();
            $article = Forum_articles::where('category_id', $article->category_id)->orderBy('id', 'DESC')->first();
            if($article!=null){
                $article->increment('hits');
            }   
            return response()->json(['title'=> $title, 'id'=> $id, 'articles'=> $articles]);
        }else{
            return response()->json('');
        }
        return response()->json('not exist');
    }




    function replytocomment($id){

      return view("forum.replytocomment", ['id'=> $id]);
    }

    function replytocomment_add(Request $request){
      $current_time=Carbon::now();
      $content = $request['content'];
      $comment_id = $request->comment_id;
      $article_id = $request->article_id;
      $reply=DB::table('replytocomment')->insertGetId([
        'content' =>$content,
        'comment_id' =>$comment_id,
        'user_id' =>Auth::user()->id,
        'article_id' =>$article_id,
        'reply_date' => $current_time,
      ]);
      $articlereplycount = DB::table('replytocomment')->where('article_id', $article_id)->get()->count();
      $commentreplycount = DB::table('replytocomment')->where('comment_id', $comment_id)->get()->count();

      $reply=ReplyToComment::with('likes', 'user')->find($reply);

     // return response()->json($reply);
      return response()->json(['reply'=> $reply, 'articlereplycount'=> $articlereplycount,'commentreplycount'=>$commentreplycount]);


    }

    function deletereply($id){
        $replyToComment= ReplyToComment::with('likes')->find($id);
        foreach ($replyToComment->likes as $like){
            ReplyReaction::find($like->id)->delete();
        }
        ReplyToComment::find($id)->delete();
      return response()->json($replyToComment);
    }

    function editReply($id){
        if(Auth::user()->user_type==1){
            $reply = ReplyToComment::find($id);
        }else{
            $reply = ReplyToComment::where('id', $id)
                ->where('user_id', Auth::user()->id)
                ->first();
        }

        return response()->json($reply);
    }



// permission to specific category of discussion forum
  function addforumcategory(){

    return view("forum.addforumcategory");
  }

  function insertforumcategory(Request $request){
    $formcategory_id = $request->formcategory_id;
    $user_id = $request->users_id;

    foreach ($user_id as $user)
    {
      DB::table('forum_access')->insert([
        'category_id'=>$formcategory_id,
        'user_id'=>$user,
      ]);
    }

    return redirect("/forum")->with('msg', 'Added successfully');
  }

  function add_Forum_Category(Request $request){

    DB::table("forum_categories")->insert([
      'en_title'=>$request->en_title,
      'da_title'=>$request->da_title,
      'ps_title'=>$request->ps_title,
      'visible'=>2,
      'coalition_id'=>4,
    ]);
    return back();
  }

  function readMoreArticles($category_id, $id){
    //$articles=Forum_articles::with('user')->where('id', '<', $id)->where('category_id', $category_id)->orderBy('id', 'DESC')->limit(10)->get();
    $articles = Forum_articles::with('user', 'comments.replies.likes', 'comments.replies.user', 'comments.likes', 'comments.user', 'likes', 'replies')->where('id', '<', $id)->where('category_id', $category_id)->orderBy('id', 'DESC')->limit(10)->get();
   
   
    return response()->json($articles);
  }

  function readMoreArticlesApi($category_id, $id){
    $articles = Forum_articles::with('user', 'comments.replies.likes', 'comments.replies.user', 'comments.likes', 'comments.user', 'likes', 'replies')->where('id', '<', $id)->where('category_id', $category_id)->orderBy('id', 'DESC')->limit(10)->get();
     
    return response()->json($articles);
  }
  
  public function articleLikes($article_id)
  {
    $likes=ArticleReaction::with('user', 'user.user_type')->where('article_id', $article_id)->orderBy('id', 'DESC')->get();
    return response()->json($likes);
  }
  
  public function commentLikes($comment_id)
  {
    $likes=CommentReaction::with('user', 'user.user_type')->where('article_id', $comment_id)->orderBy('id', 'DESC')->get();
    return response()->json($likes);
  }

  public function replyLikes($reply_id)
  {
    $likes=ReplyReaction::with('user', 'user.user_type')->where('reply_id', $reply_id)->orderBy('id', 'DESC')->get();
    return response()->json($likes);
  }
  public function commentrepliesajax($comment_id)
  {
    $forum_replies=Forum_replies::with('replies','replies.likes','replies.user')->find($comment_id);
  
    return response()->json($forum_replies);
 
  }



  
  

 
 



  }
