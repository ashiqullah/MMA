<?php

namespace App\Http\Controllers;
use App\CastAccess;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;

use DB;
use App\Cast;
use App\User;
use App\CastComment;
use App\UserContactGroup;
use App\Traits\SystemLogTrait;
use App\SystemLog;

use App\Traits\NotificationTrait;
use App\Notification;
use Illuminate\Support\Facades\Input;

class CastsController extends Controller
{
    use SystemLogTrait;
    use NotificationTrait;
    
	public function __construct()
	{
		$this->middleware('auth');
	}

	public function record() {
		$users = User::where('status', 1)->get();

		return view('streaming.record', compact('users'));	
	}

	public function home()
	{
    
	    if(Auth::user()->user_type==1){
            $previousCasts=Cast::with('comments')->orderBy('created_at', 'desc')->paginate(10);
        }else {
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            $previousCasts = Cast::with('comments')->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('created_at', 'desc')->paginate(10);
        }
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();

        return view('streaming.home', compact('previousCasts', 'groups'));
		//return response()->json([$previousCasts, $groups]);
		//return response()->json( compact('previousCasts', 'groups'));
        
    }
    
    //ustom cast code
    //
    public function videosData()
	{
	    if(Auth::user()->user_type==1){
          //  $previousCasts=Cast::with('user')->orderBy('id', 'DESC')->limit(10)->get();
          $previousCasts=Cast::with('user')->orderBy('id', 'DESC')->get();
        }else {
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            /* $previousCasts = Cast::with('user')->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('id', 'DESC')->limit(10)->get(); */
                $previousCasts = Cast::with('user')->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('id', 'DESC')->get();
        }
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();

       // return view('streaming.home', compact('previousCasts', 'groups'));
		return response()->json( compact('previousCasts', 'groups'));
        
    }

    public function videosDataLoadMore($video_id)
	{
	    if(Auth::user()->user_type==1){
            $previousCasts=Cast::with('comments')->where('id', '<', $video_id)->orderBy('id', 'DESC')->limit(10)->get();
        }else {
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            $previousCasts = Cast::with('comments')->where('id', '<', $video_id)->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('id', 'DESC')->limit(10)->get();
        }
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();

       // return view('streaming.home', compact('previousCasts', 'groups'));
		return response()->json( compact('previousCasts', 'groups'));
        
    }
    public function videosDataRefresh($video_id)
	{
	    if(Auth::user()->user_type==1){
            $previousCasts=Cast::with('comments')->where('id', '>', $video_id)->orderBy('id', 'DESC')->limit(10)->get();
        }else {
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            $previousCasts = Cast::with('comments')->where('id', '>', $video_id)->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('id', 'DESC')->limit(10)->get();
        }
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();

       // return view('streaming.home', compact('previousCasts', 'groups'));
		return response()->json( compact('previousCasts', 'groups'));
        
    }


	public function loadCastAjax($id) {
              
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            $first_cast=Cast::with('comments','user','comments.user')->where('id', $id)->first();         
        
          //  response()->json( compact('previousCasts', 'groups'));
    return response()->json(['cast' => $first_cast, 'allowed' => $allowed]);

         //   return view('streaming.home', compact('previousCasts', 'first_cast', 'groups'));
  }
  



    //


	public function loadCast($id, $page) {
        $string = Input::get ( 'page' );
        if(!$string) {
            Paginator::currentPageResolver(function () use ($page) {
                return $page;
            });
        }
        if(Auth::user()->user_type==1){
            $first_cast=Cast::with('comments')->where('id', $id)->first();
            $previousCasts=Cast::with('comments')->orderBy('created_at', 'desc')->paginate(10);
        }else {
            $first_cast=Cast::with('comments')->where('id', $id)->first();
            $allowed = CastAccess::where('user_id', Auth::user()->id)->pluck('cast_id')->all();
            $previousCasts = Cast::with('comments')->whereIn('id', $allowed)->orWhere('everyone', 1)
                ->orWhere('created_by', Auth::user()->id)->orderBy('created_at', 'desc')->paginate(10);
        }
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();

		return view('streaming.home', compact('previousCasts', 'first_cast', 'groups'));
	}

    public function getGroupajax()
    {
        $groups=DB::table('contact_groups')->select('id', 'en_name')->get();
    return response()->json($groups);



    }

	public function addComment(Request $request) {
		$this->validate($request,[
			'cast_id' => 'required',
			'comment' => 'required',                                  
		]);

		$comment = new CastComment;
		$comment->cast_id = $request->cast_id;
		$comment->user_id = Auth::id();
		$comment->comment = $request->comment;
		$comment->save();

		return redirect()->back();
    }
    
    public function ajaxaddComment(Request $request) {
		$this->validate($request,[
			'cast_id' => 'required',
			'comment' => 'required',                                  
		]);

		$comment = new CastComment;
		$comment->cast_id = $request->cast_id;
		$comment->user_id = Auth::id();
		$comment->comment = $request->comment;
    $comment->save();
  //  $insertedcomment=Cast::with('comments')->where('id', $cast_)->first();

  //	return response()->json($comment);
  $user=Auth::user();
  
  return response()->json(['comment' => $comment, 'user' => $user]);
	}

    

	function deleteCommentajax($id){

		DB::table('cast_comments')->where('id',$id)->delete();
		return response()->json("Success");
    }
    
    function editCommentajax($id){
		$comment = DB::table("cast_comments")->where('id', $id)->get();
        return response()->json($comment);

    }
    
    function updateCommentajax(Request $req){

		$id = $req->id;
		$comment = $req->comment;
		DB::table('cast_comments')
		->where('id', $id)
		->update(['comment' => $comment]);
        return response()->json($comment);
	}

	function editComment($id){
		$comment = DB::table("cast_comments")->where('id', $id)->get();
		return view("admin.casts.edit_comment", compact('comment'));

	}


	function updateComment(Request $req){

		$id = $req->id;
		$comment = $req->comment;
		DB::table('cast_comments')
		->where('id', $id)
		->update(['comment' => $comment]);
		return redirect("/casts")->with('msg', 'The comment is updated');
	}
	
	function insertvideo(Request $request){
      $this->validate($request,[
          'title' => 'required',
          'file' => 'required|file',
          'description' => 'nullable|string',                                  
        ]);  
        
      $cast = new Cast;
    
      $cast->title = $request->title;
      $cast->description = $request->description;
      $file = $request->file;
      $file->move('upload/casts', $file->getClientOriginalName());
      $file1= $request->file->getClientOriginalName();
      $cast->url = $file1;
      if($request->group_id==19){
        $cast->everyone = 1;
      }else{
        $cast->everyone = 0;  
      }
      $cast->group_id = $request->group_id;
      $cast->created_by = Auth::user()->id;
      $cast->save();
 
      if(isset($request->group_id) and $request->group_id!=0 and $request->group_id!=19){
          $user_ids=UserContactGroup::where('contact_group_id', $request->group_id)->pluck('user_id')->all();
          $users= User::whereIn('id', $user_ids)->select('id', 'email')->get();
          foreach($users as $user) {
            DB::table('cast_access')->insert([
              'user_id' => $user->id,
              'cast_id' => $cast->id
            ]);
	        $this->sendNotificationToApplicant($user->email, "A new Video Cast added by ". Auth::user()->name);
	        $this->createNotification($user->id, "A new video cast has been posted by ".Auth::user()->name, "casts", $cast->id);
          }
      }
      
      $this->createLog("A new video cast has been posted by ".Auth::user()->name);
      
      return back();

}

function insertvideoajax(Request $request){
    $this->validate($request,[
        'title' => 'required',
        'file' => 'required|file',
        'description' => 'nullable|string',                                  
      ]);  
      
    $cast = new Cast;
  
    $cast->title = $request->title;
    $cast->description = $request->description;
    $file = $request->file;
    $file->move('upload/casts', $file->getClientOriginalName());
    $file1= $request->file->getClientOriginalName();
    $cast->url = $file1;
    if($request->group_id==19){
      $cast->everyone = 1;
    }else{
      $cast->everyone = 0;  
    }
    $cast->group_id = $request->group_id;
    $cast->created_by = Auth::user()->id;
    $cast->save();

    if(isset($request->group_id) and $request->group_id!=0 and $request->group_id!=19){
        $user_ids=UserContactGroup::where('contact_group_id', $request->group_id)->pluck('user_id')->all();
        $users= User::whereIn('id', $user_ids)->select('id', 'email')->get();
        foreach($users as $user) {
          DB::table('cast_access')->insert([
            'user_id' => $user->id,
            'cast_id' => $cast->id
          ]);
          $this->sendNotificationToApplicant($user->email, "A new Video Cast added by ". Auth::user()->name);
          $this->createNotification($user->id, "A new video cast has been posted by ".Auth::user()->name, "casts", $cast->id);
        }
    }
    
    $this->createLog("A new video cast has been posted by ".Auth::user()->name);
    
    return response()->json($cast);

}
function getNotificationscount()
{
$notifications=  Notification::whereIn('entity_type', ['casts','forum','resource','news'])->where('user_id', Auth::id())->where('viewed', false)->count();
return response()->json($notifications);

}
function getNotifications()
{
  $notifications=  Notification::whereIn('entity_type', ['casts','forum'])->where('user_id', Auth::id())->where('viewed', false)
  ->join('users', 'users.id', '=', 'notifications.created_by')
  ->select('users.name as username','users.image as Image','users.gender as gender', 'notifications.*')
  ->orderBy('id', 'desc')
  ->get();
return response()->json($notifications);
}
function getNotificationView($id)
{
  $notification = Notification::find($id);
  $notification->viewed = true;
  $notification->save();
$notifications=  Notification::whereIn('entity_type', ['casts','forum'])->where('user_id', Auth::id())->where('viewed', false)->count();

 
return response()->json($notifications);
}

public function deleteNotifications() {
  Notification::where('user_id', Auth::id())->delete();
  return response()->json(true);
}
function editorVideo(Request $request){
	
	 $file = $request->file;
    $file->move('upload/Editor', $file->getClientOriginalName());
    $file1= $request->file->getClientOriginalName();
    $filename='http://192.168.43.210:85/upload/Editor/' . '' . $file1;
   /*  return response()->json($file1);
    $arr = array(
			'res' => true,
			'url' => $headimg_original
    ); */
  //  return response()->json($arr);
    return response()->json(['file' => $filename, 'uploaded' => true]);
	
}

function homepage($language_id)
{
  $slider = DB::table('slideshow')->get();
  if($language_id=='en'){
  $recent_news = DB::table('news')
  ->whereNotNull('en_title')
  ->join('users', 'users.id', '=', 'news.user_id')
  ->select('users.name as username', 'news.*')
  ->limit(10)
  ->orderBy('id', 'desc')
  ->get();
}


  elseif($language_id == 'da'){
    
    $recent_news = DB::table('news')
    ->whereNotNull('news.da_title')
    ->join('users', 'users.id', '=', 'news.user_id')
    ->select('users.name as username', 'news.*')
    ->limit(10)
    ->orderBy('id', 'desc')
    ->get();
  }
  else{    

    $recent_news = DB::table('news')
    ->whereNotNull('news.ps_title')
    ->join('users', 'users.id', '=', 'news.user_id')
    ->select('users.name as username', 'news.*')
    ->limit(10)
    ->orderBy('id', 'desc')
    ->get();
  }
  $permissions=DB::table('user_permissions')->where('user_id', Auth::id())->first();
  $notifications=  Notification::whereIn('entity_type', ['casts','forum'])->where('user_id', Auth::id())->where('viewed', false)->count();
  $user=Auth::user();

  return response()->json(['slider'=>$slider,'News'=>$recent_news,'language'=>$language_id,'permissions'=>$permissions,'notifications'=>$notifications,'user'=>$user]);

}
function homepageMore($language_id,$id)
{
  if($language_id=='en'){
  $recent_news = DB::table('news')
  ->where('news.id', '<', $id)
  ->whereNotNull('en_title')
  ->join('users', 'users.id', '=', 'news.user_id')
  ->select('users.name as username', 'news.*')
  ->limit(10)
  ->orderBy('news.id', 'desc')
  ->get();
  }
  elseif($language_id=='da')
  {
    $recent_news = DB::table('news')
    ->where('news.id', '<', $id)
    ->whereNotNull('da_title')
    ->join('users', 'users.id', '=', 'news.user_id')
    ->select('users.name as username', 'news.*')
    ->limit(10)
    ->orderBy('news.id', 'desc')
    ->get();
  }
  else
  {
    $recent_news = DB::table('news')
    ->where('news.id', '<', $id)
    ->whereNotNull('ps_title')
    ->join('users', 'users.id', '=', 'news.user_id')
    ->select('users.name as username', 'news.*')
    ->limit(10)
    ->orderBy('news.id', 'desc')
    ->get();

  }
      return response()->json($recent_news);

}

function GetNews($language_id,$id)
{
  $language_title;
  if($language_id=='en')
  {
    $language_title='news.en_title';
  }
  elseif($language_id=='da'){
    $language_title='news.da_title';
  }
  else{
    $language_title='news.ps_title';
  }

  
    $news = DB::table('news')->where('news.id', $id)
    ->whereNotNull($language_title)
    ->join('users', 'users.id', '=', 'news.user_id')
    ->select('users.name as username', 'news.*')
    ->first();
  

  return response()->json($news);

}

public function save_usertoken(Request $request)
    {
      // Comment ID
    //  $comment_id = $request->comment_id;

      // Get Comment
     // $comment = DB::table('forum_replies')->where('id', $comment_id)->first();

      // Article ID
     // $article_id = $comment->article_id;

      // User ID
      $user_id = Auth::id();

      // Insert Forum Reply
      DB::table('device_token_manager')->insert([
        'id'=>1,
        'user_id' => $user_id,
        'token' => $request->token,
        'device_id' => $request->device_id,

      ]);

      // Return Response Back
      return response()->json($request->token);

    }



}
