import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

//import {TimeAgoPipe} from 'time-ago-pipe';

import { TimeagoModule } from 'ngx-timeago';
import { IonicModule } from '@ionic/angular';

import { ArticlePage } from './article.page';

const routes: Routes = [
  {
    path: '',
    component: ArticlePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TimeagoModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ArticlePage]
})
export class ArticlePageModule {}
