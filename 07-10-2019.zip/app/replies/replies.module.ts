import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { RepliesPage } from './replies.page';
import { TranslateModule} from '@ngx-translate/core';
import { TimeagoModule, TimeagoClock } from 'ngx-timeago';
import { MyClock } from '../home/MyClock';

const routes: Routes = [
  {
    path: '',
    component: RepliesPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TranslateModule,
    TimeagoModule.forRoot({
      clock: {provide: TimeagoClock, useClass: MyClock},
    }),
    RouterModule.forChild(routes)

  ],
  declarations: [RepliesPage]
})
export class RepliesPageModule {}
