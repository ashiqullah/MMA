import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { NavController, Events,IonContent, AlertController, ModalController   } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { LanguageService } from '../providers/language/language.service';
import { LanguageModel } from '../models/language.model';
import {UserProvider} from '../providers/user/user';
import {homeProvider} from '../providers/Home/home';
import { Service } from '../settings/Laravel';
import { UserProfilePage } from '../user-profile/user-profile.page';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  @ViewChild(IonContent) content: IonContent;
  segment: string = "News";
  sliderdata: any[];
  news: any[];
  ServerUrl: string;
  Newsimage: string;
  Eventimage: string;
  mode: string = 'card';
  userID: any;
  userType: any;

  currenlanguage;
  loading: boolean = false;
  hasAccesstoaddNews: boolean = false;
  slideOpt = {
    loop: true,
    autoplay:true,
    initialSlide: 1,
    speed: 400
  };

  constructor(
    public navCtrl: NavController,
    public translate: TranslateService,
    public languageService: LanguageService,
    private userService: UserProvider,
    private homeservice: homeProvider,
    public events: Events,
    private alertCtrl: AlertController,
    private zone: NgZone,
    public modalController: ModalController
    

  ) {
    events.subscribe('language:changed', (language) => {
      this.sliderdata = [];
      this.news = [];
      if(language =='fa')
      {
        language='da';
        this.currenlanguage='da';
      }
      else{
        this.currenlanguage=language;
      }
      this.homeservice.getSlider(language).then((repsonse: any) => {
        
        console.log(repsonse);
        this.sliderdata = repsonse.slider;
        this.news = repsonse.News;
        this.content.scrollToTop(1500);
   
       });
    });

    this.listenEvents();
    this.sliderdata = [];
    this.Newsimage=Service.newsImageUrl;
    this.Eventimage=Service.eventImageUrl;
    this.news = [];
    this.ServerUrl = Service.url;
    this.currenlanguage=this.translate.currentLang;
    if(this.translate.currentLang =='fa')
    {
      this.currenlanguage='da';
    }

   

  }

  listenEvents(){
    this.events.subscribe('reloadHomepage',() => {
      this.news = [];
      this.getNews();

     //call methods to refresh content
    });
 }

  ngOnInit() {
    
    this.loading = true;
   // this.getPermission();
 

    this.homeservice.getSlider(this.currenlanguage).then((response: any) => {

      this.sliderdata = response.slider;
      this.news = response.News;


      this.userID=response.user.id;
      this.userType=response.user.user_type;
      this.hasAccesstoaddNews=(response.permissions.admin_add_news==1 || response.user.user_type==1)?true:false;
      this.userService.storeUserInfo({id: response.user.id, name: response.user.name, user_type: response.user.user_type});

      this.userService.storePermission(response.permissions);
      this.events.publish('Notification:viewed', response.notifications);
      this.events.publish('user:get',response.user);
      this.loading = false;
      console.log(response);
  
     });
  }
getNews()
{
  this.loading = true;
  this.homeservice.getSlider(this.currenlanguage).then((repsonse: any) => {

   
    this.news = repsonse.News;
    this.loading = false;
 
    console.log(this.news);
    

   });

}
async presentModal(profileId: number) {
  const modal = await this.modalController.create({
    component: UserProfilePage,
    componentProps: { value: profileId }
  });
  return await modal.present();
}

delete(newsid){
  let newsindex=this.getNewsindex(newsid);
  this.homeservice.deletenews(newsid).then((response: any) => {
    this.news.splice(newsindex, 1);



    });
    }

    getNewsindex(id){

      let news = this.news.find(x => x.id === id);
      return this.news.indexOf(news);
     } 

  makelist(){
    this.mode = 'list';
  }

  makecard(){
    this.mode = 'card';
  }
  detail(item){
/*     , {
      item:item
    } */
    this.navCtrl.navigateForward(`/news/${item.id}`);
  }

  pulished(vtype,newsid,i)
  {
console.log(newsid);

  }
  

  loadMoreNews(event) {
    //  let last: any = this.comments[this.comments.length - 1];
      let lastid= Math.min.apply(Math,this.news.map(s => s.id));
      console.log(lastid);
      this.homeservice.getMoreNews(this.currenlanguage,lastid).then((response: any) => {
        console.log(response);
        this.news = this.news.concat(response);
       // event.complete();
        event.target.complete();
    
      });
    }

    getPermission()
    {
      this.userService.getuserpermission()
        .then((response: any) => {
          this.userID=response.user.id;
          this.userType=response.user.user_type;
          this.hasAccesstoaddNews=(response.permissions.admin_add_news==1 || response.user.user_type==1)?true:false;
        this.userService.storeUserInfo({id: response.user.id, name: response.user.name, user_type: response.user.user_type});
  
         this.userService.storePermission(response.permissions);
         this.events.publish('Notification:viewed', response.notifications);
         this.events.publish('user:get',response.user);
  
  
        })
        .catch(err => {
          console.log(err);
          this.showAlert('Error', err);
        
        })
  
    }
    
    async showAlert(title, msg) {
      const alert = await this.alertCtrl.create({header: title, subHeader: msg, buttons: ['Ok']});
      alert.present();
    }

  
   async presentConfirm(newsid) {
      let alert = await this.alertCtrl.create({
        header: this.translate.instant('CONFIRM'),
        subHeader: 'Are you sure to delete this news?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              console.log('Cancel clicked');
            }
          },
          {
            text: 'Delete',
            handler: () => {
              this.zone.run(() => {
              let newsindex=this.getNewsindex(newsid);
              this.homeservice.deletenews(newsid).then((response: any) => {
                 this.news.splice(newsindex, 1);
                                });
                              });
            }
          }
        ]
      });
      alert.present();
    }
}
